#AXEL O. BALITAAN
#2022-05153

poly.lagrange <- function(data)
{
  xVal = data[[1]] # Gets the x values 
  yVal = data[[2]] # Gets the y values
  
  if ((length(xVal) == 0) || (length(yVal) == 0) || (length(xVal) != length(yVal))) # Invalid conditions
  {
    return (NA)
  }
  
  n = length(xVal) # Gets how many items there is (same with length(yVal))
  
  polystring = "function (x)" # Initializes polystring (starts with "function (x)")
  polybases = list(); # Initializes polybases (empty list)
  
  for (i in 1:n) # For each index
  {
    temp = xVal[-i] # Removes the x value of corresponding index
    
    # Constructs the numerator
    numerator = paste0("(x - ", temp[1:(n-1)], ")")
    numerator = paste0("(", paste(numerator, collapse = " * "), ")")
    
    # Constructs the denominator
    denominator = paste0("(", xVal[i], " - ", temp[1:(n-1)], ")")
    denominator = paste0("(", paste(denominator, collapse = " * "), ")")
    
    polybasesString = paste(numerator, "/", denominator); # Construct polybase string version (numerator/denominator)
    
    polystring = paste(polystring, yVal[i], "*", polybasesString); # concatenates the polybasestring to the polystring (interpolation polynomial)
    
    if (i != n) # If not yet the last equation, concatenates an extra "+" symbol
    {
      polystring = paste(polystring, "+")
    }
    
    # Constructs/evaluates the polybaseString to a polybase equation
    polybaseEq = paste("function (x)", polybasesString)
    polybaseEq = eval(parse(text = polybaseEq))
    
    polybases = append(polybases, polybaseEq) # Appends the evaluated polybase equation to the list of polybases
  }

  polyfunc = eval(parse(text = polystring)) # Evaluates the created polybasestring
  
  L = list(polybases = polybases, polystring = polystring, polyfunc = polyfunc) # Puts everything to a list
  
  return (L) # Returns the list
}

x = c(1,3,6,9)
y = log(x)
data = list(x,y)
L = poly.lagrange(data)
print(L)
