//AXEL O. BALITAAN
//2022-05153
//AVL Tree insertion

/* ********************************************************* *
 * template.c                                                *
 *                                                           *
 * Template C Source File for AVL Insert.                    *
 *                                                           *
 * !!! DO NOT EDIT THE CONTENTS OF THE MAIN FUNCTION !!!     *
 *                                                           *
 * ********************************************************* */
#include "AVL.h"
#include <stdio.h>
#include <stdlib.h>

AVL_NODE * createAVLNode(int key){
    return createBSTNode(key, NULL, NULL, NULL);
}

AVL * createAVL(int max){
    return createBST(max);
}

/**** PUT YOUR FUNCTIONS HERE ******************************/




//Function that gets height of a node
int heightOf(AVL_NODE *node)
{
	if (node == NULL)	//If the node is NULL, return -1
	{
		return -1;
	}
	return node -> height;	//else, return the height of the node
}

//Function for left rotation
void leftRotate(AVL* A, AVL_NODE * node)
{
	AVL_NODE **root = findPtrToNodePtr(A, node);	//Gets the parent pointer to the critical node, set to the root if none
	AVL_NODE *pivot = node -> right;	//Gets the pivot node

	node -> right = pivot -> left;	//Transfers the left child of pivot, as the  newright child of critical
	if (pivot -> left != NULL)
	{
		pivot -> left -> parent = node;
	}

	pivot -> left = node;	//Sets the critical node as the new left child of the pivot
	pivot -> parent = node -> parent;	//Copies critical node parent pointer to pivot's parent pointer
	

	*root = pivot;	//Points the root/parent of critical to pivot	
	node -> parent = pivot;	//Connects critical node to its new parent (the pivot)
	
	heightAdjust(node);	//Updates height
}

//Function for right rotation
void rightRotate(AVL* A, AVL_NODE * node)
{
	AVL_NODE **root = findPtrToNodePtr(A, node);	//Gets the parent pointer to the critical node, set to the root if none
	AVL_NODE *pivot = node -> left;	//Gets the pivot node

	node -> left = pivot -> right;	//Transfers the right child of pivot, as the new left child of critical
	if (pivot -> right != NULL)
	{
		pivot -> right -> parent = node;
	}

	pivot -> right = node;	//Sets the critical node as the new right child of the pivot
	pivot -> parent = node -> parent;	//Copies critical node parent pointer to pivot's parent pointer
	

	*root = pivot;	//Points the root/parent of critical to pivot
	node -> parent = pivot;	//Connects critical node to its new parent (the pivot)
	
	heightAdjust(node);	//Updates height
}

//Function that checks which rotation should be done based on balance factor and key values
void AVLBalance(AVL* A, AVL_NODE* critical, AVL_NODE *node, int balanceFactor)
{
	if (balanceFactor == 2)	//If there is an initial left leaning
	{
		if (node -> key > critical -> left -> key)	//If it is a left-right leaning
		{
			leftRotate(A, critical -> left);	//Left rotates the pivot first
		}
		rightRotate(A, critical);	//Right rotates the critical
	}
	else if (balanceFactor == -2)	//If there is an initial right leaning
	{
		if (node -> key < critical -> right -> key)	//If it is a right-left leaning
		{
			rightRotate(A, critical -> right);	//Right rotates the pivot first
		}
		leftRotate(A, critical);	//Left rotates the critical
	}
}

//Insetion and balance factor checker
void AVLInsert(AVL* A, AVL_NODE* node)
{
	insert(A, node);	//Insert node to BST

	int leftH;
	int rightH;
	int balanceFactor;

	AVL_NODE *temp = node;	//Creates a temp pointer (which moves up)

	while (1)
	{
		if (temp == NULL)	//If already reached the end, ends loop
		{
			break;
		}

		leftH = heightOf(temp -> left);	//Gets height of left child
		rightH = heightOf(temp -> right);	//gets height of right child

		balanceFactor = leftH - rightH;	//Computes balance factor

		if (balanceFactor == 2 || balanceFactor == -2)	//If there is an imbalance
		{
			AVLBalance(A, temp, node, balanceFactor);	//Passes the critical node, node inserted, and balancefactor
			break;	//Ends the loop
		}

		temp = temp -> parent;	//Iterates temp 
	}
}




/**** FUNCTIONS ABOVE **************************************/

int main(){

	char command;
	int key, result;

	AVL *A = createAVL(100);
	AVL_NODE* node;
	while(1){
		scanf(" %c", &command);

		switch(command){
			case '+':
				scanf("%d", &key);
				printf("Inserting key: %d\n", key);
				AVLInsert(A, createAVLNode(key));
				break;
			case 'p':
				printf("Tree (rotated +90 degrees): \n");
				showTree(A);
				printf("\n");
				break;
			case 'C':
				printf("Removing all contents.\n");
				clear(A);
				break;
			case 'Q':
				clear(A);
				free(A);
				return 0;
            default:
                printf("Unknown command %c\n", command);
       }
    }
}
