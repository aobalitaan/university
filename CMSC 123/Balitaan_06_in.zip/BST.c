/* ********************************************************* *
 * BST.c                                                     *
 *                                                           *
 * Contains the function definitions of all functions        *
 *    declared in BST.h.                                     *
 *                                                           *
 * !!! DO NOT EDIT LINES 11-28 !!!                           *
 *                                                           *
 * ********************************************************* */
#include "BST.h"
#include <stdio.h>
#include <stdlib.h>

// a recursive subroutine to display the BST in tree mode
void showTreeHelper(BST_NODE* node, int tabs){

	if(!node) return; // node is null, do nothing
	showTreeHelper(node->right, tabs + 1);
	for(int i=0; i<tabs; i++) printf("\t");
	printf("%d(%d)\n", node->key, node->height);
	showTreeHelper(node->left, tabs + 1);

}

void showTree(BST* B){
	showTreeHelper(B->root, 0);
}

/***********************************************************************/
/* Copy your previous function definitions for the functions in BST.h. */
/* PASTE THEM BELOW THIS COMMENT.                                      */
/***********************************************************************/

//your implementation for the functions in BST.h below !!!

//Creates a new BST Node
BST_NODE *createBSTNode(int key, BST_NODE *L, BST_NODE *R, BST_NODE *P)
{
	BST_NODE *newNode = (BST_NODE*)malloc(sizeof(BST_NODE)); //Mallocs new node

	//Initializes BST nodes attributes
	newNode -> left = L;
	newNode -> right = R;
	newNode -> parent = P;
	newNode -> key = key;
	newNode -> height = 0;
	
	return newNode; //Returns the created node
}

//Creates a BST
BST *createBST(int max)
{
	BST *B = (BST*) malloc (sizeof(BST)); //Mallocs a new BST

	//Initializes BST attributes
	B -> root = NULL;
	B -> maxSize = max;
	B -> size = 0;
	
	return B; //Returns initialized tree
}

//Checks if BST is empty
int isEmpty(BST *B)
{
	if (B -> root == NULL)
	{
		return 1;
	}
	return 0;
}

//Checks if BST is Full
int isFull(BST *B)
{
	if ((B -> size) >= (B -> maxSize))
	{
		return 1;
	}
	return 0;
}

//Checks max height from left and right tree
int max(int leftH, int rightH)
{
	if (leftH >= rightH)
	{
		return leftH;
	}
	return rightH;
}

//Updates affected heights
void heightAdjust(BST_NODE *node)
{
	
	int leftH;
	int rightH;

	while (1)
	{
		if (node == NULL) //If node is null, reached root
		{
			break; //ends loop
		}

		//Height of left and right initially set as -1
		leftH = -1;
		rightH = -1;

		if (node -> left != NULL) //If there is a left child, gets its height
		{
			leftH = node -> left -> height;
		}
		if (node -> right != NULL) //If there is a right child, gets its height
		{
			rightH = node -> right -> height;
		}
		
		node -> height = max(leftH, rightH) + 1; //Gets max of left and right chilren height and adds 1 for the height of current node
		node = node -> parent; //Iterates to the parent/above of the node in tree
	}
}

//Inserts BST node to the BST
void insert(BST *B, BST_NODE *node)
{
	if (isFull(B))
	{
		printf("BST is full.\n");
		return;
	}

	if (search(B, node -> key) != NULL)
	{
		printf("Key already in the BST.\n");
		return;
	}

	//Initializes pointers
	BST_NODE **temp = &(B -> root);
	BST_NODE *prevNode = NULL;
	BST_NODE *currNodePtr = NULL;

	while (1)
	{
		prevNode = currNodePtr; //Stores a copy of previous node (for parents)
		currNodePtr = (*temp);	//Iterates current node pointer

		if (currNodePtr == NULL) //If the current pointer is already NULL, stops
		{
			break;
		}
		
		if ((node -> key) < (currNodePtr -> key)) //If key is less than curr node, goes to the left
		{
			temp = &(currNodePtr -> left);
		}
		
		else if ((node -> key) > (currNodePtr -> key))	//else, goes to the right
		{
			temp = &(currNodePtr -> right);
		}
	}

	//Initializes the node's parent
	node -> parent = prevNode;
	//Attaches the node
	(*temp) = node;
	//Iterates BST size
	B -> size++;

	heightAdjust(node);
}

//Search function
BST_NODE *search(BST *B, int key)
{
	BST_NODE *keyNode = NULL; //Initialization for return value
	BST_NODE *temp = B -> root; //Tenp pointing to the root of the tree

	while (1)
	{
		if (temp == NULL) //If already reached the end, breaks
		{
			break;
		}
		if (temp -> key == key) //If key found break
		{
			keyNode = temp;
			break;
		}
		else if (key < (temp -> key)) //If key less than curr node key, goes to the left
		{
			temp = temp -> left;
		}
		else if (key > (temp -> key)) //If key greater than curr nide key, goes to the right
		{
			temp = temp -> right;
		}
	}

	return keyNode; //return keyNode
}

BST_NODE *minimum(BST_NODE *n)		//Function for finding the minimum of subtree
{
	while (n -> left != NULL)		//Iterates until leftmost is found
	{
		n = n -> left;
	}
	return n;
}

BST_NODE *maximum(BST_NODE *n)		//Function for finding maximum of subtree
{
	while (n -> right != NULL)		//Iterates until rightmost is found
	{
		n = n -> right;
	}
	return n;
}

BST_NODE **findPtrToNodePtr(BST *B, BST_NODE *node)	//Finds the address of the pointer in parent pointing to the node
{

	if (node -> parent == NULL)	//If no parent, returns address of root pointer
	{
		return (&(B -> root));
	}

	if (node -> parent -> right == node)	//If node is right child of parent
	{
		return (&(node -> parent -> right));
	}

	if (node -> parent -> left == node)		//If node is left child of parent
	{
		return (&(node -> parent -> left));
	}
}

void deleteNode(BST *B, BST_NODE *delPtr)
{
	//Creates a pointer to the specific pointer in parent (&(node -> parent -> left/right)) that points to node
	BST_NODE **ptrToDelPtr = findPtrToNodePtr(B, delPtr);	

	if (delPtr -> left == NULL && delPtr -> right == NULL)		//If no child
	{
		*ptrToDelPtr = NULL;	//pointer pointing to delPtr position (in parent) is set to NULL
		heightAdjust(delPtr);	//Adjusts the height of the tree
		free(delPtr);		//frees del Ptr
		return;		//ends the function
	}

	BST_NODE *delSucc = delPtr -> left;		//By default successor/replacement is set to the left child

	if ((delPtr -> right == NULL) || (delPtr -> left == NULL))		//If del has no right child
	{
		if (delSucc == NULL)		//If only right child
		{
			delSucc = delPtr -> right;
		}

		*ptrToDelPtr = delSucc;		//pointer pointing to delPtr position (in parent) is set to point to the replacement/successor
		delSucc -> parent = delPtr -> parent;		//Copies parent pointer of del to the replacement
		heightAdjust(delPtr);		//Adjusts tree height
		free(delPtr);		//Frees del ptr
		return;		//ends the function
	}

	else if (delPtr -> right != NULL)		//If 2 children
	{
		delSucc = minimum(delPtr -> right);		//Successor is set to the minimum of right subtree
		delPtr -> key = delSucc -> key;			//Copies the key of successor to del
		return (deleteNode(B, delSucc));		//delete successor node
	}
}

int delete(BST *B, int key)
{
	if (isEmpty(B))		//Checks if BST is empty
	{
		printf("BST is empty!\n");
		return -1;
	}

	BST_NODE *delPtr = search(B, key);	//Gets the location of the node to be deleted

	if (delPtr == NULL)	//If location is null, the key is not in the BST
	{
		printf("Key [%d] not in BST!\n", key);
		return -1;
	}

	deleteNode(B, delPtr);	//If deletion valid, performs deletion

	printf("Key [%d] deleted.\n\n", key);
	return key;
}

void clear(BST *B)
{
	if (isEmpty(B))
	{
		printf("BST not cleared, already empty.\n");
		return;
	}

	while (B -> root != NULL)	//While root of the tree is not yet NULL
	{
		printf("Key [%d] deleted.\n", B -> root -> key);	//Prints the key to be deleted	
		deleteNode(B, B -> root);	//Deletes the root
	}
	printf("Cleared!\n");
}
