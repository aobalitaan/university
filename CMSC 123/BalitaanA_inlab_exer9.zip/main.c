// BALITAAN, AXEL O.
// 2022 - 05153
// Graphs

#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
#include "graph.h"

//Implement your functions here

GRAPH *createGraph(int vertices)	// Function for creating the graph
{
	GRAPH *G = (GRAPH*) malloc (sizeof(GRAPH));	// Mallocs a graph

	G -> num_vertices = vertices;

	//Initializes adjacency matrix
	G -> matrix = (int**) malloc (sizeof(int*) * vertices);

	for (int i = 0; i < vertices; i++)
	{
		G -> matrix [i] = (int*) malloc (sizeof(int) * vertices);
		for (int j = 0; j < vertices; j++)
		{
			G -> matrix [i][j] = 0;
		}
	}

	return G;
}

void insertEdge(GRAPH *G, int u, int v)
{
	//Checks if vertices are in bounds
	if ((u + 1 > (G -> num_vertices)) || (v + 1 > (G -> num_vertices)))
	{
		printf("Invalid Vertices!\n");
		return;
	}

	//Appends value if valid
	G -> matrix [u][v] = 1;
	G -> matrix [v][u] = 1;

	printf("Successfully inserted edge %d %d\n", u+1, v+1);
}

int *createVisited(GRAPH *G)
{
	int *visited = (int*) malloc (sizeof(int) * G -> num_vertices);	//Allocates visited array
	
	for (int i = 0; i < (G -> num_vertices); i++)
	{
		visited[i] = 0;	//Initializes visited to zero
	}

	return visited;
}

void dfs(GRAPH *G, int start)
{
	int ver = G -> num_vertices;

	//Checks if the starting vertex is an isolated vertex
	int flag = 0;
	for (int i = 0; i < ver; i++)
	{
		if (G -> matrix[start][i])
		{
			flag = 1;
		}
	}
	if (flag == 0)
	{
		printf("Isolated vertex\n");
		return;
	}

	//If not isolated

	int *visited = createVisited(G);	//Creates visited array
	STACK *L = createStack();	//Creates empty stack
	
	//Pushes start
	push(L, createNode(start));

	int curr_v;

	while (1)
	{
		int curr_v = pop(L);	//Pops top of the stack

		if (curr_v == -1)	//If the stack is already empty, stops
		{
			break;
		}

		if (visited[curr_v])	//If the vertex(index) is already visited, just starts again the loop without proceeding
		{
			continue;
		}

		printf("%i ", curr_v + 1);	//Prints non-visited vertex
		visited[curr_v] = 1;	//Marks the vertex as visited

		for (int i = ver; i > 0; i--)	//Push adjacent matrix
		{
			if (G -> matrix[curr_v][i])
			{
				push(L, createNode(i));
			}
		}
	}

	//Frees allocated visited and stack
	free(visited);
	free(L);
}

void printStack(STACK *L) //prints content of the stack
{
	if (isEmpty(L))
	{
		printf("Stack is empty\n");
		return;
	}

	NODE *temp = L -> head;
	while (1)
	{
		if (temp = NULL)
		{
			break;
		}

		printf("%i ", temp -> value);
		temp = temp -> next;
	}

	printf("\n");
}

NODE* createNode(int data)
{
	//Create individual node
	NODE *node = (NODE*) malloc (sizeof(NODE));

	node -> value = data;
	node -> next = NULL;

	return node;
}

STACK* createStack()
{
	//Creates stack
	STACK *L = (STACK*) malloc (sizeof(STACK));

	L -> head = NULL;

	return (L);
}

int isEmpty(STACK *L)
{
	return(L -> head == NULL ? 1 : 0);
}

void push(STACK *L, NODE* node)
{
    node -> next = L -> head;
    L -> head = node;
}

int pop(STACK *L)
{
	//Pops of the Top of Stack
	if (isEmpty(L))
	{
		return (-1);
	}

    NODE *del = L -> head;
    int del_value = del -> value;

    L -> head = L -> head -> next;
    free(del);

    return del_value;
}

void printMatrix(GRAPH *G)
{
	for (int i = 0; i < (G -> num_vertices); i++)
	{
		for (int j = 0; j < (G -> num_vertices); j++)
		{
			printf("%i\t", G -> matrix[i][j]);
		}
		printf("\n");
	}
}

void freeMatrix(GRAPH *G)
{
	//If adjacency matrix is empty doesn't free it
	if (G -> matrix == NULL)
	{
		return;
	}

	//Frees adjacency matrix
	for (int i = 0; i < G ->num_vertices; i ++)
	{
		free(G -> matrix[i]);
	}

	free (G -> matrix);
	G -> matrix = NULL;
}

int main() {
	char command;
	int vertices, lines, u, v;

	scanf("%d", &vertices);
	GRAPH *G = createGraph(vertices);

	while(1) {
		scanf(" %c", &command);

		switch(command) {
			case '+':
				scanf(" %d %d", &u, &v);
				insertEdge(G, u-1, v-1); //there's a -1 since we use 0-indexing in the arrays
				//printf("Successfully inserted edge %d %d\n", u, v);
				break;
			case '#':
				printf("\nDFS: ");
				dfs(G, 0); //0 is the initial value since we use 0-indexing (it still represents vertex 1)
				printf("\n");
				break;
			case 'p':
				printf("\nADJACENCY MATRIX: \n");
				printMatrix(G);
				break;
			case 'f':
				freeMatrix(G);
				break;
			case 'Q':
				freeMatrix(G);
				free(G);
				return 0;
			default:
				printf("Unknown command: %c\n", command);
		}
	}
}