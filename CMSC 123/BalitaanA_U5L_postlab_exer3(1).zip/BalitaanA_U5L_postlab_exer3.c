//AXEL O. BALITAAN
//2022-05153
//BST ADT with insert, search, and traversing function

#include "BST.h"
#include <stdio.h>
#include <stdlib.h>

//Creates a new BST Node
BST_NODE *createBSTNode(int key, BST_NODE *L, BST_NODE *R, BST_NODE *P)
{
	BST_NODE *newNode = (BST_NODE*)malloc(sizeof(BST_NODE)); //Mallocs new node

	//Initializes BST nodes attributes
	newNode -> left = L;
	newNode -> right = R;
	newNode -> parent = P;
	newNode -> key = key;
	newNode -> height = 0;
	
	return newNode; //Returns the created node
}

//Creates a BST
BST *createBST(int max)
{
	BST *B = (BST*) malloc (sizeof(BST)); //Mallocs a new BST

	//Initializes BST attributes
	B -> root = NULL;
	B -> maxSize = max;
	B -> size = 0;
	
	return B; //Returns initialized tree
}

//Checks if BST is empty
int isEmpty(BST *B)
{
	if (B -> root == NULL)
	{
		return 1;
	}
	return 0;
}

//Checks if BST is Full
int isFull(BST *B)
{
	if ((B -> size) >= (B -> maxSize))
	{
		return 1;
	}
	return 0;
}

//Checks max height from left and right tree
int max(int leftH, int rightH)
{
	if (leftH >= rightH)
	{
		return leftH;
	}
	return rightH;
}

//Updates affected heights
void heightAdjust(BST_NODE *node)
{
	
	int leftH;
	int rightH;

	while (1)
	{
		if (node == NULL) //If node is null, reached root
		{
			break; //ends loop
		}

		//Height of left and right initially set as -1
		leftH = -1;
		rightH = -1;

		if (node -> left != NULL) //If there is a left child, gets its height
		{
			leftH = node -> left -> height;
		}
		if (node -> right != NULL) //If there is a right child, gets its height
		{
			rightH = node -> right -> height;
		}
		
		node -> height = max(leftH, rightH) + 1; //Gets max of left and right chilren height and adds 1 for the height of current node
		node = node -> parent; //Iterates to the parent/above of the node in tree
	}
}

//Inserts BST node to the BST
void insert(BST *B, BST_NODE *node)
{
	if (isFull(B))
	{
		printf("BST is full.\n");
		return;
	}

	//Initializes pointers
	BST_NODE **temp = &(B -> root);
	BST_NODE *prevNode = NULL;
	BST_NODE *currNodePtr = NULL;

	while (1)
	{
		prevNode = currNodePtr; //Stores a copy of previous node (for parents)
		currNodePtr = (*temp);	//Iterates current node pointer

		if (currNodePtr == NULL) //If the current pointer is already NULL, stops
		{
			break;
		}
		
		if ((node -> key) <= (currNodePtr -> key)) //If key is less than curr node, goes to the left
		{
			temp = &(currNodePtr -> left);
		}
		
		else if ((node -> key) >= (currNodePtr -> key))	//else, goes to the right
		{
			temp = &(currNodePtr -> right);
		}
	}

	//Initializes the node's parent
	node -> parent = prevNode;
	//Attaches the node
	(*temp) = node;
	//Iterates BST size
	B -> size++;

	heightAdjust(node);
}

//Search function
BST_NODE *search(BST *B, int key)
{
	BST_NODE *keyNode = NULL; //Initialization for return value
	BST_NODE *temp = B -> root; //Tenp pointing to the root of the tree

	while (1)
	{
		if (temp == NULL) //If already reached the end, breaks
		{
			break;
		}
		if (temp -> key == key) //If key found break
		{
			keyNode = temp;
			break;
		}
		else if (key < (temp -> key)) //If key less than curr node key, goes to the left
		{
			temp = temp -> left;
		}
		else if (key > (temp -> key)) //If key greater than curr nide key, goes to the right
		{
			temp = temp -> right;
		}
	}

	return keyNode; //return keyNode
}

//a recursive subroutine to display the BST in tree mode
void showTreeHelper(BST_NODE *node, int tabs){

	if(!node) return; //node is null, do nothing
	showTreeHelper(node -> right, tabs + 1);
	for(int i=0; i<tabs; i++) printf("\t");
	printf("%d(%d)\n", node -> key, node -> height);
	showTreeHelper(node -> left, tabs + 1);

}


void showTree(BST *B){
	showTreeHelper(B -> root, 0);
}

//Function for printing a list of node pointers
void listPrint(BST_NODE *walkList[], int listSize)
{
	for (int i = 0; i < listSize; i++)
	{
		printf("%i", walkList[i] -> key);
		printf("%s", (i < (listSize - 1))?", ":"\n");
	}
	
}

//Function for traversing the tree
void treeTraversal(BST_NODE *walkList[], int *indexPtr, BST_NODE *node, char type)
{
	if (node != NULL)		//If node is already null, stops the recursion
	{
		if (type == '<') 												//If the type is PREORDER, node is added to the list first
		{
			walkList[*indexPtr] = node;	//Adds the node to the list 							
			(*indexPtr)++;	//Iterates index
		}

		treeTraversal(walkList, indexPtr, node -> left, type); 			//Does recursive function to left child

		if (type == '/') 												//If the type is INORDER, node is added to the list after left
		{
			walkList[*indexPtr] = node;	//Adds the node to the list 							
			(*indexPtr)++;	//Iterates index
		}

		treeTraversal(walkList, indexPtr, node -> right, type); 		//Does recursive function to right child

		if (type == '>') 												//If the type is INORDER, node is added to the list last								
		{
			walkList[*indexPtr] = node;	//Adds the node to the list 							
			(*indexPtr)++;	//Iterates index
		}
	}
}

//Function for preorder walk
void preorderWalk(BST *B)
{
	if (isEmpty(B))	//Doesn't proceed if list is empty
	{
		printf("BST is empty.\n");
		return;
	}

	int listSize = B->size;	//Gets the size of BST
	BST_NODE *preorderList[listSize];	//Initializes a list based on the size

	int index = 0;	//Initializes index counter

	BST_NODE *node = B ->  root;	//Initial node set to the root
	treeTraversal(preorderList, &index, node, '<');	//Traverse the tree, indicates the type and passes the address of index counter for iterating
		
	listPrint(preorderList, listSize);	//Prints the list
}

void inorderWalk(BST *B)
{
	if (isEmpty(B))	//Doesn't proceed if list is empty
	{
		printf("BST is empty.\n");
		return;
	}

	int listSize = B->size;	//Gets the size of BST
	BST_NODE *inorderList[listSize];	//Initializes a list based on the size

	int index = 0;	//Initializes index counter

	BST_NODE *node = B ->  root;	//Initial node set to the root
	treeTraversal(inorderList , &index, node, '/');	//Traverse the tree, indicates the type and passes the address of index counter for iterating

	listPrint(inorderList, listSize);	//Prints the list
}

void postorderWalk(BST *B)
{
	if (isEmpty(B))	//Doesn't proceed if list is empty
	{
		printf("BST is empty.\n");
		return;
	}

	int listSize = B->size;	//Gets the size of BST
	BST_NODE *postorderList[listSize];	//Initial node set to the root
		
	int index = 0;	//Initializes index counter

	BST_NODE *node = B ->  root;	//Initial node set to the root
	treeTraversal(postorderList, &index, node, '>');	//Traverse the tree, indicates the type and passes the address of index counter for iterating

	listPrint(postorderList, listSize);	//Prints the list
}

int main(){

	char command;
	int key, result;
	
	BST *B = createBST(100);
	BST_NODE *node;
	while(1){
		scanf(" %c", &command);

		switch(command){
			case '+':
				scanf("%d", &key);
				printf("Inserting key: %d\n", key);
				insert(B, createBSTNode(key, NULL, NULL, NULL));
				break;
			case '?':
				scanf("%d", &key);
				printf("Searching node with key: %d. Location: %p\n", key, search(B, key));
				//(nil) means NULL pointer
				break;
			case 'p':
				printf("Tree (rotated +90 degrees): \n");
				showTree(B);
				printf("\n");
				break;
			case 'E':
				printf("BST %s empty.\n", isEmpty(B)?"is":"is not");
				break;
			case 'F':
				printf("BST %s full.\n", isFull(B)?"is":"is not");
				break;
			case '<':
				printf("Pre-order Traversal: ");
				preorderWalk(B);
				printf("\n");
				break;
			case '>':
				printf("Post-order Traversal: ");
				postorderWalk(B);
				printf("\n");
				break;
			case '/':
				printf("In-order Traversal: ");
				inorderWalk(B);
				printf("\n");
				break;
			case 'Q':
				return 0;
			default:
				printf("Unknown command: %c\n", command);
		}
	}

	return 0;
}