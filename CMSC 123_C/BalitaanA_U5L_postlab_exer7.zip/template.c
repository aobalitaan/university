/*
 * Name: BALITAAN, AXEL O.
 * Lab Section: U5L
 * Program Description:	Postlab exercise, Heap ADT with insertion and deletion function (minheap), and sorting (Descending order)
*/

#include "heap.h"
#include <stdio.h>
#include <stdlib.h>

int left(int index){
  return(2 * index); 
}

int right(int index){
  return(2 * index + 1); 
}

int parent(int index){
  return(index / 2); 
}

void printHeapHelper(HEAP *H, int index, int tabs){
	if(index > H->size) return;
	else{
		printHeapHelper(H, right(index), tabs + 1);
		for(int i=0; i<tabs; i++) printf("\t");
		printf("%d\n", H->heap[index]);
		printHeapHelper(H, left(index), tabs + 1);
	}
}

void printHeap(HEAP *H){
	if(H!=NULL && H->size>0){
		printHeapHelper(H, 1, 0);
	}else{
		printf("Empty heap!\n");
	}
}


// IMPLEMENT FUNCTIONS HERE

// Creates Heap ADT
HEAP* createHeap(int maxSize)
{
	HEAP *H = (HEAP*) malloc(sizeof(HEAP));	// Mallocs a new heap adt
	H -> maxSize = maxSize;	// Initializes heap max size
	H -> size = 0;	// Initial size of heap set to 0

	H -> heap = (int*) malloc (sizeof(int) * (maxSize + 1));	// Initialize heap array

	return H;	// Returns initialized heap
}

// Checks if heap is full
int isFull(HEAP *H)
{
	if (H -> size == H -> maxSize)	// Checks heap size compared to maxSize
	{
		return 1;
	}
	return 0;
}

// Checks if heap is empty
int isEmpty(HEAP *H)
{
	if (H -> size == 0)	// Checks heap size
	{
		return 1;
	}
	return 0;
}

// Clears all the content of the heap
void clear(HEAP *H)
{
	if (isEmpty(H))	// If the heap is already empty
	{
		return;
	}

	int count = H -> size;

	for (int i = 0; i <= count; i++)	// Performs deletion (H -> size) times
	{
		deleteM(H);
	}
}

// (ADDITIONAL) Swap Function
void swap(HEAP *H, int index1, int index2)
{
	int temp = (H -> heap)[index1];	// Stores index1 key
	(H -> heap)[index1] = (H -> heap)[index2];	// Pastes index2 key to index1
	(H -> heap)[index2] = temp;	// Paste temp (index1 key) to index2
}

// Insert Function
void insert(HEAP *H, int key)
{
	if (H == NULL)	// If H not initialized
	{
		printf("Heap not yet created!\n");
		return;
	}

	if (isFull(H))	// If heap is full, doesn't proceed
	{
		printf("Heap is full!\n");
		return;
	}

	//If heap is not full

	(H -> size)++;	// Increase size
	(H -> heap)[H -> size] = key;	// Appends key

	//Perculation UP

	int cur = H -> size;	// sets the cur to the newly inserted
	int par;

	while (1)
	{
		par = parent(cur);	// Gets the parent of cur

		// If cur is already the root, or cur is already greater than its parent
		if ((cur == 1) || (H -> heap)[cur] >= (H -> heap)[par])	
		{
			break;
		}

		// Swaps cur and its parent, iterated cur
		swap(H, cur, par);
		cur = par;
	}
}


// Checks left and right child of a node
int checkLR(HEAP *H, int cur)
{
	// If there is no right child or left is less than right
	if ((right(cur) > H -> size) || (H -> heap)[left(cur)] <= (H -> heap)[right(cur)])
	{
		return (left(cur));	// Return left
	}
	return (right(cur));	// Defaults to return right
}

// Delete Function
int deleteM(HEAP *H)
{
	if (H == NULL)	// If H not initialized
	{
		printf("Heap not yet created!\n");
		return (-123);
	}

	if (isEmpty(H))	// If H is empty
	{
		return (-123);
	}

	// Finds the root to return
	int toDel = (H -> heap)[1];

	// Swaps root and last inserted
	swap(H, 1, H -> size);
	(H -> size)--;

	//Perculate Down

	int smallerChild;
	int cur = 1;

	while (1)
	{
		smallerChild = checkLR(H, cur);	// Gets the smaller child
		
		//If the smaller child out of bounds, or cur less than the smaller child
		if ((smallerChild > H -> size) || (H -> heap)[cur] <= (H -> heap)[smallerChild])
		{
			break;
		}

		//Swaps cur and smaller child, iterates cur
		swap (H, cur, smallerChild); 
		cur = smallerChild;
	}

	//Returns deleted value;
	return (toDel);
}

//Returns sorted version of the heap
int *heapSort(HEAP *H)
{
	if ((H == NULL) || (H -> size == 0))
	{
		return NULL;
	}

	int maxSize = H -> maxSize;
	int size = H -> size;

	//Creates a copy of the heap
	HEAP *H_copy = createHeap(maxSize);
	for (int i = 1; i <= size; i++)
	{
		insert(H_copy, (H -> heap)[i]);
	}

	//Initialize an int array for sorted
	int *H_sorted;
	H_sorted = (int*) malloc (sizeof(int) * (size + 1));

	//Deletes from root of H_copy and appends it to the array
	for (int i = size; i >= 1; i--)
	{
		H_sorted[i] = deleteM(H_copy);
	}

	//Frees H_copy
	free(H_copy -> heap);
	free(H_copy);

	//Returns sorted array
	return (H_sorted);
}

int main(){

	char command;
	int key, result, type;
    int* sorted;

	HEAP *H = createHeap(30);

	while(1){
		scanf(" %c", &command);

		switch(command){
			case '+':
				scanf("%d", &key);
				printf("Inserting key: %d...\n", key);
				insert(H, key);
				break;
			case '-':
				printf("Removing root from tree...\n");
				result = deleteM(H); // result is unused
				break;
			case 'p':
				printf("Printing the heap (rotated +90 degrees)...\n");
				printHeap(H);
				printf("\n");
				break;
			case 'E':
				printf("Heap %s empty.\n", isEmpty(H)?"is":"is not");
				break;
			case 'F':
				printf("Heap %s full.\n", isFull(H)?"is":"is not");
				break;
			case 'C':
				printf("Removing all contents...\n");
				clear(H);
				break;

			case '~':
				printf("The sorted version of the heap:\n");
				sorted = heapSort(H);
				for(key=1; key <= H->size; key++)
					printf("%4d", sorted[key]);
				printf("\n");
				free(sorted);
				break;

			case 'Q':
				free(H->heap);
				free(H);
				return 0;
			default:
				printf("Unknown command: %c\n", command);
		}
	}

	return 0;
}