//AXEL O. BALITAAN
//2022-5153
//CMSC 123 - U5L
//BST Deletion

#include <stdio.h>
#include <stdlib.h>

#include "BalitaanA_U5L_postlab_exer3.c" //imports previous exer

BST_NODE *minimum(BST_NODE *n)		//Function for finding the minimum of subtree
{
	while (n -> left != NULL)		//Iterates until leftmost is found
	{
		n = n -> left;
	}
	return n;
}

BST_NODE *maximum(BST_NODE *n)		//Function for finding maximum of subtree
{
	while (n -> right != NULL)		//Iterates until rightmost is found
	{
		n = n -> right;
	}
	return n;
}

BST_NODE **findPtrToNodePtr(BST *B, BST_NODE *node)	//Finds the address of the pointer in parent pointing to the node
{

	if (node -> parent == NULL)	//If no parent, returns address of root pointer
	{
		return (&(B -> root));
	}

	if (node -> parent -> right == node)	//If node is right child of parent
	{
		return (&(node -> parent -> right));
	}

	if (node -> parent -> left == node)		//If node is left child of parent
	{
		return (&(node -> parent -> left));
	}
}

void deleteNode(BST *B, BST_NODE *delPtr)
{
	//Creates a pointer to the specific pointer in parent (&(node -> parent -> left/right)) that points to node
	BST_NODE **ptrToDelPtr = findPtrToNodePtr(B, delPtr);	

	if (delPtr -> left == NULL && delPtr -> right == NULL)		//If no child
	{
		*ptrToDelPtr = NULL;	//pointer pointing to delPtr position (in parent) is set to NULL
		heightAdjust(delPtr);	//Adjusts the height of the tree
		free(delPtr);		//frees del Ptr
		return;		//ends the function
	}

	BST_NODE *delSucc = delPtr -> left;		//By default successor/replacement is set to the left child

	if (delPtr -> right == NULL)		//If del has no right child
	{
		*ptrToDelPtr = delSucc;		//pointer pointing to delPtr position (in parent) is set to point to the replacement/successor
		delSucc -> parent = delPtr -> parent;		//Copies parent pointer of del to the replacement
		heightAdjust(delPtr);		//Adjusts tree height
		free(delPtr);		//Frees del ptr
		return;		//ends the function
	}

	else if (delPtr -> right != NULL)		//If only has right children or has 2 children
	{
		delSucc = minimum(delPtr -> right);		//Successore is set to the minimum of right subtree
		delPtr -> key = delSucc -> key;		//Copies the key of successor to del
		return (deleteNode(B, delSucc));		//delete successor node
	}
}

int delete(BST *B, int key)
{
	if (isEmpty(B))		//Checks if BST is empty
	{
		printf("BST is empty!\n");
		return -1;
	}

	BST_NODE *delPtr = search(B, key);	//Gets the location of the node to be deleted

	if (delPtr == NULL)	//If location is null, the key is not in the BST
	{
		printf("Key [%d] not in BST!\n", key);
		return -1;
	}

	deleteNode(B, delPtr);	//If deletion valid, performs deletion

	printf("Key [%d] deleted.\n\n", key);
	return key;
}

void clear(BST *B)
{
	if (isEmpty(B))
	{
		printf("BST not cleared, already empty.\n");
		return;
	}

	while (B -> root != NULL)	//While root of the tree is not yet NULL
	{
		printf("Key [%d] deleted.\n", B -> root -> key);	//Prints the key to be deleted	
		deleteNode(B, B -> root);	//Deletes the root
	}
	printf("Cleared!\n");
}

int main(){

	char command;
	int key, result;

	BST *B = createBST(100);
	BST_NODE* node;
	while(1){
		scanf(" %c", &command);

		switch(command){
			case '+':
				scanf("%d", &key);
				printf("Inserting key: %d\n", key);
				insert(B, createBSTNode(key, NULL, NULL, NULL));
				break;
			case '-':
				scanf("%d", &key);
				printf("Removing node with key: %d\n", key);
				result = delete(B, key); // result is unused. print if u want
				break;
			case '?':
				scanf("%d", &key);
				printf("Searching node with key: %d. Location: %p\n", key, search(B, key));
				// (nil) means NULL pointer
				break;
			case 'p':
				printf("Tree (rotated +90 degrees): \n");
				showTree(B);
				printf("\n");
				break;
			case '<':
				printf("Pre-order Traversal: ");
				preorderWalk(B);
				printf("\n");
				break;
			case '>':
				printf("Post-order Traversal: ");
				postorderWalk(B);
				printf("\n");
				break;
			case '/':
				printf("In-order Traversal: ");
				inorderWalk(B);
				printf("\n");
				break;
			case 'm':
				node = minimum(B->root);
				if(node) printf("Minimum value: %d\n", node->key);
				else printf("(BST empty)\n");
				break;
			case 'M':
				node = maximum(B->root);
				if(node) printf("Maximum value: %d\n", node->key);
				else printf("(BST empty)\n");
				break;
			case 'E':
				printf("BST %s empty.\n", isEmpty(B)?"is":"is not");
				break;
			case 'F':
				printf("BST %s full.\n", isFull(B)?"is":"is not");
				break;
			case 'C':
				printf("Removing all contents.\n");
				clear(B);
				break;
			/* uncomment this for postlab
			case '[':
				scanf("%d", &key);
				node = search(B, key);
				if(!node){
					printf("%d not found\n", key);
				}else{
					node = predecessor(node);
					if(node)printf("Predecessor of %d is %d.\n", key, node->key);
					else printf("No predecessor for %d\n", key);
				}
				break;
			case ']':
				scanf("%d", &key);
				node = search(B, key);
				if(!node){
					printf("%d not found\n", key);
				}else{
					node = successor(node);
					if(node)printf("Successor of %d is %d.\n", key, node->key);
					else printf("No successor for %d\n", key);
				}
				break;
			*/
			case 'Q':
				clear(B);
				free(B);
				return 0;
			default:
				printf("Unknown command: %c\n", command);
		}
	}
	return 0;
}