package bookstore;

//Import for Scanner
import java.util.Scanner;

//BOOKSTORE CLASS

public class Bookstore {
	
	//Attribute for bookstore name
	String bookstore_name;
	
	//Bookstore's booklist and bookcount
	Book[] book_list;
	int book_count;
	
	//Bookstore's authorlist and authorcount
	Author[] author_list;
	int author_count;
	
	//Constants for max book and author counts the bookstore could hold
	final static int MAX_BOOK_COUNT = 50;
	final static int MAX_AUTHOR_COUNT = 50;
	
	//Constructor call for the bookstore
	public Bookstore(String bookstore_name)
	{
		//Initializes bookstore name
		this.bookstore_name = bookstore_name;
		
		//Initializes bookstore's list of books
		this.book_list = new Book[MAX_BOOK_COUNT];
		this.book_count = 0;
		
		//Initializes bookstore's list of authors
		this.author_list = new Author[MAX_AUTHOR_COUNT];
		this.author_count = 0;
	}
	
	//Method for Main Menu
	public void showMainMenu()
	{
		//Initializes an input scanner
		Scanner input = new Scanner(System.in);
		
		//Initial greetings
		System.out.println("------------------------");
		System.out.println("Welcome to " + this.bookstore_name + "!");
		System.out.println("What would you like to do today?");
		
		int choice;
		
		//Main Menu loops unless exited
		while (true)
		{
			System.out.println("[1] Add new records");
			System.out.println("[2] View records");
			System.out.println("[3] Search");
			System.out.println("[0] Exit");
			
			//Gets user choice, returns -1 if the input was string
			choice = enterChoice(input);
			
			//If user chose to exit
			if (choice == 0)
			{
				//Ends the loop
				break;
			}
			
			//If user chose to add new records
			if (choice == 1)
			{
				addRecord(input);
			}
			//If user chose to view records
			else if (choice == 2)
			{
				//views records, passes the bookstore's booklist
				viewRecord(this.book_list);
			}
			//If user chose search function
			else if (choice == 3)
			{
				search(input);
			}
			//If user choice is an invalid one (a string)
			else if (choice == -1)
			{
				continue;
			}
			//Hidden option for View State
			else if (choice == 99)
			{
				viewState();
			}
			//If user choice is an integer but not in choices
			else
			{
				System.out.println("Invalid input!\n");
			}
			System.out.println("What would you like to do next?");
			
		}
		
		//Closes scanner and exits program
		input.close();
		System.out.println("\nThank you for using " + this.bookstore_name + " app");
		System.out.println("------------------------");
	}
	
	//Method for getting user choice in main menu
	public int enterChoice(Scanner input)
	{
		int choice;
		
		try
		{
			//Gets user input
			choice = input.nextInt();
			//Returns if no anomalies
			return choice;
		}
		catch (Exception e)
		{
			//Tells user if they inputed a string instead of int
			System.out.println("------------------------");
			System.out.println("     Type Mismatch!     ");
			System.out.println("------------------------");
			
			//And returns an indicator/flag
			input.nextLine();
			return (-1);
		}
	}
	
	//Method for adding a new record
	public void addRecord(Scanner input)
	{
		//If already reached maximum book count, tells user and doesn't proceed
		if (this.book_count >= MAX_BOOK_COUNT)
		{
			System.out.println("------------------------");
			System.out.println("Booklist is full!");
			System.out.println("------------------------");
			return;
		}
		
		//Gets Book Details from the user, [0] = title, [1] = author name
		String[] newBookDetails = getRecord(input);
		
		//Looks for the author in database, 
		//if existing returns index 
		//if not existing returns a flag
		int authorIndex = authorSearch (newBookDetails[1]);
		
		//If the author is not in system and author list is full doesn't proceed with adding book and author
		if ((this.author_count >= MAX_AUTHOR_COUNT) &&
			(authorIndex == -1))
		{
			System.out.println("------------------------");
			System.out.println("Authorlist is full!");
			System.out.println("------------------------");
			return;
		}
		
		//If the author is a new one (indicated by a flag)
		if (authorIndex == -1)
		{
			//Instantiate a new author object
			Author newAuthor = new Author(newBookDetails[1], this.author_count);
			
			//Adds the instantiated author to the author list, gives the index of it, iterates author count
			this.author_list[this.author_count] = newAuthor;
			authorIndex = this.author_count;
			this.author_count++;
		}
		
		//Instantiates a new book object based on the inputted details
		Book newBook = new Book(newBookDetails[0], author_list[authorIndex], this.book_count);
		
		//Adds the book in the author's list of book
		//Indicates true if successfully added
		//Indicates false if author's booklist is full already
		if (author_list[authorIndex].addBook(newBook) == true)
		{
			//If added successfully in the author's booklist
			//Adds the book in the bookstore's booklist and iterates book cout
			this.book_list[this.book_count] = newBook;
			this.book_count++;
		}
	}
	
	//Method for viewing records, accepts a booklist
	public void viewRecord(Book[] booklist)
	{
		//If the booklist is empty, doesn't proceed
		if (booklist[0] == null)
		{
			System.out.println("------------------------");
			System.out.println("The list is empty!");
			System.out.println("------------------------");
			return;
		}
		
		//Prints the books in the booklist
		System.out.println("-----LIST OF BOOKS------");
		
		for (Book book : booklist)
		{
			//Ends if already in the end of the booklist
			if (book == null)
			{
				break;
			}
			//Prints book details
			System.out.println("[" + book.book_id +"] " + book.book_title);
			System.out.println("    Author: " + book.book_author.author_name);
		}
		
		System.out.println("------------------------");
	}

	//Method for finding the author in the authorlist, accepts the name of the author
	public int authorSearch(String author_name)
	{
		
		//Counter variable index
		int authorIndex = 0;
		
		//Looks for the index of the author
		for (Author author : this.author_list)
		{
			//If already in the last item of the list, ends the loop
			if (author == null)
			{
				break;
			}
			//If the author is found
			if (author.author_name.toLowerCase().equals(author_name.toLowerCase()))
			{
				//Returns the index
				return authorIndex;
			}
			//Iterates index
			authorIndex++;
		}
		//Returns a flag that author is not yet in the database
		return (-1);
	}
	
	//Method for getting book details from user
	public String[] getRecord(Scanner input)
	{
		//Refresh input buffer
		input.nextLine();
		
		
		//Continuously gets book title unless valid (non-empty)
		String book_title;
		while (true)
		{
			System.out.println("------------------------");
			System.out.print("Title: ");
			book_title = input.nextLine();
			
			//If title is non-empty, ends the loop
			if (!(book_title.trim().equals("")))
			{
				break;
			}
			
			System.out.println("------------------------");
			System.out.println("Book Title can't be empty!");
		}
		
		//Continuously gets book author unless valid (non-empty)
		String book_author;
		while (true)
		{
			System.out.println("------------------------");
			System.out.print("Author: ");
			book_author = input.nextLine();
			
			//If author is non-empty, ends the loop
			if (!(book_author.trim().equals("")))
			{
				break;
			}
			
			System.out.println("------------------------");
			System.out.println("Book Author can't be empty!");
		}
		
		System.out.println("------------------------");
		
		//Returns the book details in an array
		String[] newBookDetails = new String[2];
		newBookDetails[0] = book_title;
		newBookDetails[1] = book_author;
		return newBookDetails;
	}
	
	
	//Method for search choice
	public void search(Scanner input)
	{
		//Refresh input buffer
		input.nextLine();
		
		//Continuously gets author name unless valid (non-empty)
		String author_name;
		while (true)
		{
			System.out.println("------------------------");
			System.out.print("Enter search key (author): ");
			author_name = input.nextLine();
			
			//If author is non-empty, ends the loop
			if (!(author_name.trim().equals("")))
			{
				break;
			}
			
			System.out.println("------------------------");
			System.out.println("Author name can't be empty!");
		}
		System.out.println("------------------------");
		
		//Finds the author in the authorlist, returns index if found, returns -1 if not
		int authorIndex = authorSearch(author_name);
		
		//If author not found, doesn't proceed
		if (authorIndex == -1)
		{
			System.out.println("Author name does not exist.");
			System.out.println("------------------------");
			return;
		}
		
		//Indicates that the author was found, and prints their books
		System.out.println("Author [" + author_list[authorIndex].author_name + "] exists.");
		viewRecord(this.author_list[authorIndex].author_books);
	}

	//Method for viewState
	public void viewState()
	{
		//Prints bookstore details
		System.out.println("=========================");
		System.out.println("BOOKSLAY APP");
		System.out.println("Bookstore Name: " + this.bookstore_name);
		
		//Prints books in the booklist
		System.out.println("-------------------------");
		System.out.println("Books:");
		System.out.println("-------------------------");
		for (Book book : book_list)
		{
			if (book == null)
			{
				break;
			}
			book.viewState();
			System.out.println("-------------------------");
		}
		
		//Prints authors in the authorlist
		System.out.println("-------------------------");
		System.out.println("Authors:");
		System.out.println("-------------------------");
		for (Author author : author_list)
		{
			if (author == null)
			{
				break;
			}
			author.viewState();
			System.out.println("-------------------------");
		}
		System.out.println("=========================");
	}
}
