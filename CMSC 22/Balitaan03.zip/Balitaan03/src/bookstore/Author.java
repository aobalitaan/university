package bookstore;

//AUTHOR CLASS

public class Author {
	//Author basic information
	int author_id;
	String author_name;
	
	//Author's books information
	Book[] author_books;
	int author_bookcount;
	
	//Constant for max books an author could hold
	final static int AUTHOR_MAXBOOKCOUNT = 20;
	
	//Constructor call for author
	public Author(String author_name, int author_count)
	{
		//Initializes a new author's attributes
		this.author_name = author_name;
		this.author_id = author_count + 1;
		
		//Initializes author's booklist
		this.author_books = new Book[AUTHOR_MAXBOOKCOUNT];
	}
	
	//Method for adding a book in author's catalog
	public boolean addBook(Book newBook)
	{
		//If the author already reached max number of books, doesn't add it
		if (this.author_bookcount >= AUTHOR_MAXBOOKCOUNT)
		{
			System.out.println("Author booklist is full!");
			//returns an indicator that it wasn't added
			return false;
		}
		
		//If okay, adds the book and iterates bookcount
		this.author_books[this.author_bookcount] = newBook;
		this.author_bookcount++;
		
		//Returns and indicator that it was added
		return true;
	}
	
	//Method for viewstate
	public void viewState()
	{
		//Prints author info
		System.out.println("Author ID: " + author_id);
		System.out.println("Author Name: " + author_name);
		System.out.println("Author BookCount: " + author_bookcount);
		
		//Prints author's books
		System.out.println("Books:");
		for (Book book : author_books)
		{
			if (book == null)
			{
				break;
			}
			System.out.println(book.book_title);
		}
		
	}
}
