package bookstore;

//BOOK CLASS

public class Book {
	//Book's basic information
	String book_title;
	Author book_author;
	int book_id;
	
	//Constructor call for books
	public Book(String book_title, Author book_author, int book_count)
	{
		//Initializes book information
		this.book_title = book_title;
		this.book_author = book_author;
		this.book_id = book_count + 1;
	}
	
	//Method for viewstate
	public void viewState()
	{
		//Prints book information
		System.out.println("Book Title: " + book_title);
		System.out.println("Book Author: " + book_author.author_name);
		System.out.println("Book ID: " + book_id);
	}
}
