/***************************
 * 
 * A bookstore system that uses object-oriented programming (OOP) 
 * principles to manage books and authors. The system allows users to create a 
 * bookstore object that contains a list of book and author objects. Each book
 * contains the author information and each author has a list of books they
 * published.
 * 
 * Axel O. Balitaan
 * 2023-09-29 10:03
 * 
 ***************************/



package main;

//Imports the bookstore package
import bookstore.*;

public class Main {

	public static void main(String[] args) {
		//Instantiates a new Bookstore object 
		Bookstore BookSlay = new Bookstore("BOOKSLAY");
		
		//Calls the main menu of the bookstore instantiated
		BookSlay.showMainMenu();
	}

}
