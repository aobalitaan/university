/***************************
 * 
 * A voting system that applies encapsulation principle
 * that hides sensitive poll methods from the main
 * Filters users from user id and limits votes up to
 * 9 votes per user.
 * 
 * Axel O. Balitaan
 * 2023-10-06 11:00
 * 
 ***************************/


package main;

import electoral.Users;
import electoral.Poll;

public class Main 
{
	public static void main(String[] args) 
	{
		
		//Instantiate user and poll objects
		Users currUser = new Users();
		Poll currPoll = new Poll();
		
		//Run tally method
		runTallyProcess(currUser, currPoll);
	}

	private static void runTallyProcess(Users currUser,Poll currPoll) 
	{
		
		//Loops while not exiting
		while (true)
		{
			//If the current user is in employees
			if (currUser.checkEmployeeId())
			{
				//Runs the main menu of poll (includes vote-related methods set in private)
				String result = currPoll.menu();
				
				//If the menu resulted to null, the choice was invalid
				if (result == null)
				{
					System.out.println("Invalid choice!");
					continue;
				}
				//If the menu resulted to "exit", the choice was to logout and breaks the loop
				else if (result == "exit")
				{
					break;
				}
				//If the menu resulted to "results", the choice was to view the results
				else if (result == "results")
				{
					currPoll.getVote();
				}
		
				//Just continues the loop if voting succeeded/failed
				
				//currPoll.viewState();
			}
			//If user is not, just repeats and look for a new employee Id
			else
			{
				currUser.begin();
			}
				
		}
		
		//Closes the scanners of the user and poll objects, and prints a goodbye message
		currUser.closeScanner();
		currPoll.closeScanner();
		System.out.println("Goodbye!");
	}

}		
		
		
	//instantiate a User object
	//instantiate a Poll object
	//call runTallyProcess(______, ______)
				
	// while loop
		// calls checkEmployeeID of the User class, which will return a boolean
		// if valid employeeID
		//calls menu() of Poll class . Assign it to String "choice"
		//use the choice as the parameter to call castVote() in the Poll class. Assign it to String "result"
	
		//if the result is null, print "Invalid choice!" then continue
		//if the result is "exit" then break
		//if the result is "results", call the getVote() of the Poll class
		//else, call the setVote() of the Poll class and pass "result" as the parameter
	// else, call the begin() function of the User class and store it in String employeeId
		
		//the program terminates
			


