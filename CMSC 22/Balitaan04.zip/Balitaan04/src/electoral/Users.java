/***************************
 * USERS CLASS
 * -Responsible in getting user information
 * and checking if user's employee Id is in the 
 * list of accepted employeeId
 * 
 * Axel O. Balitaan
 * 2023-10-06 11:00
 * 
 ***************************/


package electoral;

import java.util.Arrays;
import java.util.Scanner;

public class Users 
{
	//Private array of accepted Ids
	private final static String employeeIdList[] = {"1101008", "1001028", "1200802"};
	
	//Attributes of Users class
	private Scanner sc;
	private String employeeId;
	
	//Constructor call of user
    public Users()
    {
    	//Starts a scanner
    	sc = new Scanner(System.in);
    	//Initializes employeeId to empty string
    	employeeId = "";
    }
    
    //Public method for begin (called in the main menu)
    public void begin()
    {
    	//Prints entry message
    	System.out.println("Welcome to ICS electoral system!");
    	
    	//And, gets valid employee Id input
    	String employeeId;
    	while (true)
    	{
    		System.out.print("Enter your Employee ID to begin: ");
    		employeeId = sc.nextLine();
    		
    		//Only accept non-empty input string
    		if (!(employeeId.trim().equals("")))
    		{
    			break;
    		}
    		
    		System.out.println("Employee ID can't be empty!");
    		
    	}
    	
    	//And sets the employee id the instantiated user object
    	this.employeeId = employeeId;
    }
	
    //Method for checking if the employee Id is in the list of accepted ids
    public boolean checkEmployeeId()
    {
    	return (Arrays.asList(employeeIdList).contains(employeeId));
    }
    
    //Method for closing the scanner
    public void closeScanner()
    {
    	this.sc.close();
    }
}    
    
    /**
	ATTRIBUTES: provide the proper access modifiers
		scanner
	 	employeeId
	 */
    
    /**
	CONSTRUCTORS: provide the proper access modifiers
		______ Users{}{}
	 */

	/**
	 METHODS: provide the proper access modifiers
	 	begin()
	 		- This method's task is to present the welcome text and prompt the user to enter their employee ID
	 		- prints ("Welcome to ICS electoral system!\n Enter your Employee ID to begin: ")
	 		- returns the employeeId
	 		
	 	checkEmployeeId()
	 		- This method checks the list of employees and returns a boolean result
	 		- returns true if users exist, otherwise false
	 */
	

