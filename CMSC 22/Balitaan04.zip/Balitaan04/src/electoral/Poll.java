/***************************
 * POLL CLASS
 * 
 * -Responsible in getting and performing poll related 
 * methods. Most are set to private to encapsulate
 * from the main
 * 
 * Axel O. Balitaan
 * 2023-10-06 11:00
 * 
 ***************************/

package electoral;

import java.util.Scanner;

public class Poll {
	//Private array of aspirants
	private final static String aspirantList[] = {"Mylah", "Rudolf", "Sammy", "Carl"};
	
	//Private attributes 
	private Scanner sc;
	private String[] poll;
	private String aspirant;
	
	//Additional attribute (constant) for max number of votes
	private final static int pollCount = 9;
	
	//Constructor call for Poll
	public Poll()
	{
		//Initializes a poll array
		poll = new String[pollCount];
		//Opens a new scanner
		sc = new Scanner(System.in);
	}
    
	//Public method for the menu of program (called in the main)
	public String menu()
	{	
		//Gets user choice
		String choice;
		
		//Doesn't accept empty input
		while (true)
    	{
			//Prints main menu choices
			System.out.println("\n=== Menu ===");
			
			int count = 1;
			for (String aspirant : aspirantList)
			{
				System.out.println("[" + count + "] Vote for " + aspirant);
				count++;
			}
			System.out.println("[" + (count) + "] Show Results");
			System.out.println("[0] Logout");
			
			//Gets main menu choice
    		System.out.println("Enter choice");
    		choice = sc.nextLine();
    		
    		//If choice is not empty breaks loop
    		if (!(choice.trim().equals("")))
    		{
    			break;
    		}
    		//else doesn't accept it and continue looping
    		System.out.println("Choice can't be empty!");
    	}
    	
		//Calls the private castVote method of this poll and pass user choice as parameter
		//Will return the user's choice to the main (whether user exited, view votes, or successful/failed in voting)
		return (this.castVote(choice));
	}
	
	//Method for user casting vote based on choice in menu
	private String castVote(String choice)
	{
		
		//Converts user choice into an integer
		int choice_index;
		try
		{
			//tries to parse user choice
			choice_index = Integer.parseInt(choice);
		}
		catch (Exception e)
		{
			//If input was a string, returns null
			return (null);
		}
		
		//If user choice is 0, returns "exit
		if (choice_index == 0)
		{
			return ("exit");
		}
		//If user choice is Show Results
		if (choice_index == aspirantList.length + 1)
		{
			return ("results");
		}
		//If user choice an integer but not within the bounds
		if ((choice_index < 0) || (choice_index > aspirantList.length))
		{
			return (null);
		}
		
		//If user choice within the bounds, calls the private method that sets their vote to the respective aspirant
		return (this.setVote(choice_index));
	}
	
	//Method for setting user vote
	private String setVote(int choice_index)
	{
		//Checks if the user can still vote
		int voteCount = size();
		
		//If not, prints message and doesn't continue (indicates that voting fails)
		if (voteCount >= pollCount)
		{
			System.out.println("Cannot cast vote");
			return ("fail");
		}
		
		//If everything user is still allowed to vote
		
		//Gets aspirant name
		this.aspirant = aspirantList[choice_index - 1];
		
		//Appends it to the poll array
		poll[voteCount] = this.aspirant;
		
		//Prompts that the vote was counted
		System.out.println("Vote Counted.");
		
		//Indicates that voting was successful
		return ("success");
	}
	
	//Public method for showing results
	public void getVote()
	{
		//Initializes vote count
		int votes;
		
		System.out.println("\n-- Poll Results --");
		
		//For every aspirant
		for (String aspirant : aspirantList)
		{
			//Count their votes
			votes = countInstances(aspirant);
			
			//And prints it
			System.out.println("Number of votes for " + aspirant + ": " + votes);
		}
	}
	
	
	//Private method for checking how many votes the user did
	private int size()
	{
		//Initialized at zero
		int pollVoteCount = 0;
		
		//Iterates for every vote a user casted
		while ((pollVoteCount < pollCount) && (poll[pollVoteCount] != null))
		{
			//Counts vote
			pollVoteCount++;
		}
		
		return pollVoteCount;
	}
	
	//Private method for counting an aspirant's vote
	private int countInstances(String aspirant)
	{
		//Initialized at zero
		int aspirantVote = 0;
		
		//Iterates for every vote they got
		for (String vote : poll)
		{
			if (vote == aspirant)
			{
				aspirantVote++;
			}
		}
		
		return aspirantVote;
	}
	
	//Method for closing scanner
	 public void closeScanner()
	 {
	    this.sc.close();
	 }
	 
	 public void viewState()
	 {
		 for (String vote : this.poll)
		 {
			 System.out.println(vote);
		 }
	 }

	/**
    ATTRIBUTES: provide the proper access modifiers
    	final static String array named aspirantList[], containing the values { “Mylah”, “Rudolf”, “Sammy”, “Carl” }
    	scanner
    	poll array
    	aspirant
    **/
	
	/**
    CONSTRUCTORS: provide the proper access modifiers
	     ______ Poll(){
	     instantiate a poll array of size 9
	     
	     }
    **/
	
	
    /**
     METHODS: provide the proper access modifiers
     	menu() 
     		- This is a non-void method that prints the main menu and returns the user's choice.
			- prints "Enter a choice" and returns the choice
		
		setVote()
			- This method appends the candidate's name to an array called poll.
			- checks the size prints "Cannot cast vote" when the number of votes in the poll is 10
		
		getVote()
			- invokes countInstances() to count the number of votes tallied by the clerk and prints the result.
     		- displays ("Number of votes for " + aspirant + ": " + votes)
     	castVote()
     		- accepts choice as parameter
     		- checks which number corresponds to the aspirant (ex. if choice == "1" then this.aspirant == "Mylah")
     		- returns the string of the aspirant with the corresponding choice
 		size()
 			- private method
 			- will check the number of votes in the poll
 			- returns the number of votes in the poll
 			
 			-NOTE: you cannot create an array in Java without specifying its size
 				   since the array has a fixed size, you need to perform the counting of votes in the poll yourself
     	countInstances()
     		- will check how many votes an aspirant get
     		- returns the number of votes of the aspirant
     		
     		-NOTE: will only return ONE value, w/c is per aspirant
     		 	   this method is repeatedly called in getVote() which contains the main iterator
     **/



}
