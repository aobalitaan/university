package Color;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

//INTERFACE
interface color {
	
	//Declaration of a fixed ArrayList of colors
	public static final ArrayList<String> COLORLIST = new ArrayList<>(Collections.unmodifiableList(Arrays.asList(
	        "Yellow", 
	        "Yellow-Orange", 
	        "Orange", 
	        "Red-Orange", 
	        "Red", 
	        "Red-Violet", 
	        "Violet", 
	        "Blue-Violet", 
	        "Blue", 
	        "Blue-Green", 
	        "Green", 
	        "Yellow-Green"
	    )));
	
	//Additional declaration of a fixed ArrayList of color schemes
	public static final ArrayList<String> SCHEMELIST = new ArrayList<>(Collections.unmodifiableList(Arrays.asList(
	        "Monologous",
	        "Complementary",
	        "Analogous",
	        "Triadic",
	        "Tetradic"
	    )));
	
	//Initializations of methods for method overloading
	void showColors(String scheme, int color);
	void showColors(String scheme, int color, int i);
	void showColors(String scheme, int color, int i, int j);
	void showColors(String scheme, int color, int i, int j, int k);
}
