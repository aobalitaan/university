package Color;

public class colorScheme implements color{
	
	public colorScheme()
	{
		//Empty constructor for colorScheme, just to access its methods without error
	}
	
	//METHOD OVERLOADING
	
	//If Monologous
	public void showColors(String scheme, int color)
	{
		System.out.println("The " + scheme + " colors for " + COLORLIST.get(color) + 
				" are the different shades of " + COLORLIST.get(color) + ".");
	}
	
	//If Complementary
	public void showColors(String scheme, int color, int i)
	{
		System.out.println("The " + scheme + " color to " + COLORLIST.get(color) + 
				" is " + COLORLIST.get(i) + ".");
	}
	
	//If Triadic or Analogous
	public void showColors(String scheme, int color, int i, int j)
	{
		System.out.println("The " + scheme + " colors to " + COLORLIST.get(color) + 
				" are " + COLORLIST.get(i) + " and " + COLORLIST.get(j) + ".");
	}
	
	//If Tetradic
	public void showColors(String scheme, int color, int i, int j, int k)
	{
		System.out.println("The " + scheme + " colors to " + COLORLIST.get(color) + 
				" are " + COLORLIST.get(i) + ", " + COLORLIST.get(j) + ", and " + COLORLIST.get(k) + ".");
	}
}
