//BALITAAN, AXEL O.
//2022-05153
//CMSC 22 YZ2L


package cashier;

import java.util.Scanner;

public class AdvancedPOS
{	
	
	//Method for getting user input for int data type, used for menu choices (Overload ver 1)
	public static int enterChoice(Scanner input, int choice)
	{
		//Try catch for invalid type
		try
		{
			//If valid (int) just return the input
			System.out.println("Select an option: ");
			choice = input.nextInt();
			return choice;
		}
		catch(Exception e)
		{
			//If valid but string returns -1 as a flag
			System.out.println("==========TYPE ERROR=========");
			System.out.println("Wrong input type!");
			System.out.println("=============================");
			input.nextLine();
			return (-1);
		}
	}
	
	//Method for getting user input for float data type, used for price (Overload ver 2)
	public static float enterChoice(Scanner input, float choice)
	{
		try
		{
			//If valid (float) just return the input
			choice = input.nextFloat();
			return choice;
		}
		catch(Exception e)
		{
			//If valid but string returns -1 as flag
			System.out.println("==========TYPE ERROR=========");
			System.out.println("Wrong input type!");
			System.out.println("=============================");
			input.nextLine();
			return (-1);
		}
	}
	
	//Method for viewing products
	public static void viewProducts(String[] productNameList, float[] productPriceList, int productCounter)
	{
		System.out.println("====== :: PROD LIST :: ======");
		
		//If the product array is empty, early returns
		if (productCounter == 0)
		{
			System.out.println("System: Product List is empty. Add more!");
			return;
		}
		
		//Loops through the products
		for (int i = 0 ; i < productCounter; i ++)
		{
			System.out.println("[" + (i+1) + "] " + productNameList[i] + " @ " + productPriceList[i] + " PHP");
		}
		
		System.out.println("====== :: PROD LIST :: ======");
	}
	
	//Method for adding products
	public static int addProduct(Scanner input, String[] productNameList, float[] productPriceList, int productCounter)
	{
		System.out.println("====== :: ADD  PROD :: ======");
		
		//Refreshes input buffer
		input.nextLine();
		
		//Gets product name
		String productName;
		while (true)
		{
			System.out.println("=============================");
			System.out.println("Enter the name of the product: ");
			productName = input.nextLine();
			
			if (productName.isEmpty() == false)
			{
				break;
			}
			
			System.out.println("Name can't be empty.");
		}
		
		
		
		//Gets product price, loops as long as invalid
		float productPrice = -1;
		while (true)
		{
			System.out.println("=============================");
			System.out.println("Enter the price of the product: ");
			
			productPrice = enterChoice(input, productPrice);
			if (productPrice >= 0)
			{
				break;
			}
		}
		
		//If valid, adds them to the array of products information
		productNameList[productCounter] = productName;
		productPriceList[productCounter] = productPrice;
		
		System.out.println("====== :: ADD  PROD :: ======");
		
		//Iterates product counter
		return productCounter + 1;
	}
	
	//Method for updating product
	public static void updateProduct(Scanner input, String[] productNameList, float[] productPriceList, int productCounter)
	{
		
		input.nextLine();
		
		//Loops as long as the input is empty
		String productName;
		while (true)
		{
			System.out.println("=============================");
			System.out.println("Enter the name of the product you wish to update:");
			
			productName = input.nextLine();
			if (productName.isEmpty() == false)
			{
				break;
			}
			System.out.println("Name can't be empty.");
		}
		
		
		//Finds if the product is in the product array, default is -1 as a flag
		int indexToUpdate = -1;
		
		for (int i = 0; i < productCounter; i++)
		{
			//If found sets the index
			if (productNameList[i].equals(productName))
			{
				indexToUpdate = i;
			}
		}
		
		//If flag is -1 (not in product array), early returns
		if (indexToUpdate == -1)
		{
			System.out.println("System: This product does not exist!");
			return;
		}
		
		//If found, continues with replacing it
		System.out.println("=============================");
		System.out.println("Replace with: ");
		
		//Gets new product name, loops as long as input is empty
		String newproductName;
		while (true)
		{
			newproductName = input.nextLine();
			if (newproductName.isEmpty() == false)
			{
				break;
			} 
			System.out.println("Name can't be empty.");
		}
		
		//Gets new product price, loops as long as input is invalid
		float newproductPrice = -1;
		while (true)
		{
			System.out.println("=============================");
			System.out.println("Enter price: ");
			newproductPrice = AdvancedPOS.enterChoice(input, newproductPrice);
			if (newproductPrice >= 0)
			{
				break;
			}
			System.out.println("Enter valid price.");
		}
		
		//If all are valid, prompts the user
		System.out.println("=============================");
		System.out.println("System: Done");
		System.out.println("Sucessfully replaced: ");
		System.out.println("Old: " + productNameList[indexToUpdate] + " @ " + productPriceList[indexToUpdate] + " PHP");
		System.out.println("New: " + newproductName + " @ " + newproductPrice + " PHP");
		
		//Updates the product list
		productNameList[indexToUpdate] = newproductName;
		productPriceList[indexToUpdate] = newproductPrice;
	}
	
	
	//Method for product management menu
	public static int productManagement(Scanner input, String[] productNameList, float[] productPriceList, int productCounter)
	{
		//Loops as long as not going back to menu
		while (true)
		{
			System.out.println("====== :: PROD MGMT :: ======");
			System.out.println("[0] Go Back");
			System.out.println("[1] View Products");
			System.out.println("[2] Add Product");
			System.out.println("[3] Update Product");
			
			//Gets user choice for the page
			int prodMgmtChoice = -1;
			prodMgmtChoice = AdvancedPOS.enterChoice(input, prodMgmtChoice);
			
			//If user wants to exit
			if (prodMgmtChoice == 0)
			{
				System.out.println("====== :: PROD MGMT :: ======");
				return productCounter;
			}
			
			//If user input is invalid (string)
			if (prodMgmtChoice == -1)
			{
				continue;
			}
			
			//If user wants to view products
			if (prodMgmtChoice == 1)
			{
				AdvancedPOS.viewProducts(productNameList, productPriceList, productCounter);	
			}
		
			//If user wants to add product
			else if (prodMgmtChoice == 2)
			{
				productCounter = AdvancedPOS.addProduct(input, productNameList, productPriceList, productCounter);
			}
			
			//If user wants to update product
			else if (prodMgmtChoice == 3)
			{
				System.out.println("====== :: EDIT PROD :: ======");
				
				//If product list not empty, continues to the update product page
				if (productCounter > 0)
				{
					AdvancedPOS.viewProducts(productNameList, productPriceList, productCounter);
					AdvancedPOS.updateProduct(input, productNameList, productPriceList, productCounter);
				}
				//If empty, doesn't proceed
				else
				{
					System.out.println("System: Product List is empty. No Products to Edit!");
				}
				
				System.out.println("====== :: EDIT PROD :: ======");
			}
			//If input integer invalid / not in choices
			else
			{
				System.out.println("=============================");
				System.out.println("Invalid Input!");
			}
		}
	}
	
	//Method main 
	public static void main(String[] args) 
	{
		//Initializes data arrays and counter
		String[] productNameList = new String[100];
		float[] productPriceList = new float[100];
		int productCounter = 0;
		
		//Initializes input scanner
		Scanner input = new Scanner(System.in);
		
		System.out.println("Welcome to the Byte-sized POS System!");
		System.out.println("Enter the items you wish to purchase");
		
		//Menu continues unless break by 0
		while (true)
		{
			System.out.println("====== :: MAIN MENU :: ======");
			System.out.println("[0] Exit");
			System.out.println("[1] Product Management");
			
			//Gets user input
			int mainMenuChoice = -1;
			mainMenuChoice = AdvancedPOS.enterChoice(input, mainMenuChoice);
			
			//If user chooses exit
			if (mainMenuChoice == 0)
			{
				System.out.println("====== :: MAIN MENU :: ======");
				System.out.println("Goodbye!");
				break;
			}
			
			//If user input is a string
			if (mainMenuChoice == -1)
			{
				continue;
			}
			
			//If user input is an integer but not in choices (not 1)
			if (mainMenuChoice != 1)
			{
				System.out.println("=============================");
				System.out.println("Invalid Input!");
				continue;
			}
			
			System.out.println("====== :: MAIN MENU :: ======");
			
			//If user selected 1
			productCounter = AdvancedPOS.productManagement(input, productNameList, productPriceList, productCounter);
		}
	}
}
