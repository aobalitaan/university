//AXEL O. BALITAAN
//2022-05153
//CMSC 22 - YZ2L

package cashier;

import java.util.Scanner;

public class SimplePOS {
	public static void main(String[] args)
	{	
		System.out.println("Welcome to the Byte-sized POS System!");
		System.out.println("Enter the items you wish you purchase!");
		
		//Scanner for user input
		Scanner input = new Scanner(System.in);
		
		int choice;
		
		//Try catch for the whole code
		try
		{
			
			//Loop for the main program
			while (true)
			{
				
				//Loop for valid main menu choice
				while (true)
				{
					
					//Try catch for valid main menu input (integer)
					try 
					{
						
						System.out.println("======MAIN MENU======");
						System.out.println("[0] Exit");
						System.out.println("[1] New Transaction");
						
						//Gets main menu choice from user
						System.out.println("Select an option:");
						choice = input.nextInt();
						
						//If integer input: breaks the loop
						break;
					}
					
					//If not an integer
					catch(Exception e)
					{
						//Refreshes input buffer and loops back again
						System.out.println("Wrong input! Try again.");
						input.nextLine();
					}	
				}
				
				//If user selected exit (0)
				if (choice == 0)
				{
					//breaks the while true of the whole program
					System.out.println("Goodbye!");
					break;
				}
				
				//If main menu choice is an integer but not valid
				else if (choice != 1)
				{
					//Restarts program from the main menu
					System.out.println("Input not in choice!");
					continue;
				}
				
				//If user selected 1
				
				//Array for products name bought
				String products[] = new String[100];
				
				//Array for products price bought
				float product_total[] = new float[100];
				
				//Number of products bought
				int productCount = 0;
				
				//For referencing
				String product_name[] = {"Algo Roll", "Data Maki", "OSnigiri", "Systemaki"};
				float product_pricelist[] = {180.00f, 100.00f, 125.00f, 175.50f};
				
				
				int order;
				
				//Loop for the order page
				while (true)
				{
					//Try catch for order input
					try 
					{
						System.out.println("=====================");
						System.out.println("[0] Checkout and Print Receipt");
						System.out.println("[1] Algo Roll @180.00 PHP");
						System.out.println("[2] Data Maki @100.00 PHP");
						System.out.println("[3] OSnigiri @125.00 PHP");
						System.out.println("[4] Systemaki @175.50 PHP");
						
						//Gets order from user
						System.out.println("Select an option:");
						order = input.nextInt();
						
						//If order selected 0, ends the order page while loop
						if (order == 0)
						{
							break;
						}
						
						//If order selected is integer but not in choices, starts again the order page
						else if ((order < 0)||(order > 4))
						{
							System.out.println("Input not in choice!");
							continue;
						}
						
						//If order selected is valid, adds them to the arrays and loops again the order page
						products[productCount] = product_name[order - 1];
						product_total[productCount] = product_pricelist[order - 1];
						productCount++;
						
						System.out.println("You bought 1 " + product_name[order - 1]);
					}
					
					//If order input not an integer
					catch(Exception e)
					{
						
						//Refreshes input buffer and loops back again
						System.out.println("Wrong input! Try again.");
						input.nextLine();
					}
				}
				
				//Happens when the order loop ends (user selected 0)
				float total = 0;
					
				System.out.println("======CHECKOUT RECEIPT======");	
				
				//Loops through the arrays
				for (int i = 0; i < productCount; i++)
				{
					System.out.println(products[i] + "\t" + product_total[i] + " PHP");
					
					//Calculates order total
					total = total + product_total[i];
				}
				
				//Prints total and VAT
				System.out.println("The total amount due is: " + total + " PHP");
				System.out.println("VAT (12%): " + (total*0.12f) + " PHP");	
				
				float cash;
				
				//Gets cash input from user
				while (true)
				{
					//Try catch for valid input in cash (float)
					try 
					{
						System.out.println("\nCash Amount:");
						cash = input.nextFloat();
						
						//If cash is greater than total (valid), breaks the loop 
						if (cash >= total)
						{
							break;
						}
						//If not, continues getting input
						System.out.println("Insufficient Amount!");
					}
					//If cash input not a float
					catch(Exception e)
					{
						//Refreshes input buffer and loops back again
						System.out.println("Wrong input! Try again.");
						input.nextLine();
					}	
				}
				
				//If cash is enough, prints the final part of the receipt
				System.out.println("Change: " + (cash - total) + " PHP");
				System.out.println("Thank you for shopping with us!");
				System.out.println("======CHECKOUT RECEIPT======\n");
				
				//Continue to the start of the program (Main Menu Page)
			}
		}
		//If ever code fails or completes, the scanner for input resets
		finally
		{
			//Closes input
			input.close();
		}
	}
}
