/***************************
 * EXERCISE #7
 * 
 * An eymis server implementation using 
 * concurrency principles and threads. Simulates 
 * simultaneous student enlistment with course slots
 * and server running time limitations
 * 
 * 
 * Axel O. Balitaan
 * Created: 2023-11-5 9:00
 * Modified : 2023-11-6 8:23
 * 
 ***************************/

// DO NOT EDIT THIS

package main;

import system.*;


public class Main {

    public static void main(String[] args) {
    	
    	// we create a runnable server which is ran to the thread eymis
        Server server = new Server("Ey-Mis");
        Thread eymis = new Thread(server);       
        eymis.start();
       
        /*
         * 11 instances of students
         * name, standing, student ID, restTime
         */
        Student.students.add(new Student("Mylah Anacleto", Student.SENIOR, "2020-0001", 1000));
        Student.students.add(new Student("Rodolfo Camaclang", Student.JUNIOR, "2021-0002", 2000));
        Student.students.add(new Student("Carl Angcana", Student.FRESHMAN, "2023-0003", 3000));
        Student.students.add(new Student("Sammy Capuchino", Student.FRESHMAN, "2023-0004", 4000));
        Student.students.add(new Student("Erika Cunanan", Student.SOPHOMORE, "2022-0005", 3000));
        Student.students.add(new Student("JM Bawagan", Student.SENIOR, "2020-0006", 7000));
        Student.students.add(new Student("Reginald Recario", Student.SENIOR, "2020-0007", 7000));
        Student.students.add(new Student("Perico Dionisio", Student.SOPHOMORE, "2022-0008", 7000));
        Student.students.add(new Student("Prince Aragones", Student.SOPHOMORE, "2022-0009", 3000));
        Student.students.add(new Student("O-Neil Geronimo", Student.SOPHOMORE, "2022-0010", 3000));
        Student.students.add(new Student("Ariel Doria", Student.SOPHOMORE, "2022-0018", 15000));
        
        // Course instance
        Course course = new Course("CMSC 22", 4118);
        
        // all students call the clickEnlist method
        for (Student student : Student.students) {
            student.clickEnlist(eymis, server, course);
        }
        
        // the server will try and wait to be terminated before printing the state of the course
        try {
        	eymis.join();
            System.out.println(server.getName()+" server is now closed!.\n");
            course.viewState();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
