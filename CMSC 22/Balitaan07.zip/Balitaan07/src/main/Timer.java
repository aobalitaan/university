/*
 * Run this to simulate timers in Java
 */
package main;
import system.*;

public class Timer {
    public static void main(String[] args) {
    	Clock clock = new Clock();
        Thread timer = new Thread(clock); 
    	
        timer.start(); // Start the thread

        try {
        	timer.join(); // Wait for the thread to finish
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        
        System.out.println("Thread has completed.");
    }
}