package system;

import java.util.ArrayList;

public class Course {
    private String courseName;
    private int courseNumber;
    private ArrayList<Student> enlistedStudents;
    
    public static int MAXSIZE = 6; //maximum number of slots
    private int slots;
  
    /*
     * Course constructor
     * create the proper constructor
     */
    
    public Course(String courseName, int courseNumber) {
     this.courseName = courseName;
     this.courseNumber = courseNumber;
     this.slots = MAXSIZE;
     
     this.enlistedStudents = new ArrayList<Student>();
    }

    public String getCourseName() {
        return courseName;
    }

    public int getCourseNumber() {
        return courseNumber;
    }
    
    /* create method enlistStudent (a critical section)
     * called by Server.enlist()
     * accepts student object
     * check first if there are enough slots, 
     * use this.slots in checking number of slots
     *  -> then add to the enlistedStudent array
     *  -> reduce the slots
     * 	-> print the success prompt
     * 	-> return true
     *  
     * if no slots left, prompt the user
     * 	-> return false
     
     * NOTE: use the successPrompt and courseFull methods 
     */
   
    //enlistStudent function, set to default
    synchronized boolean enlistStudent(Student student)
    {
    	if (this.slots == 0)	//If the course has no slots
    	{
    		courseFull(student);	//Prompts student, and doesn't proceed with enlistment
    		return false;	//Returns false
    	}
    	
    	//If there is/are slot/s
    	enlistedStudents.add(student);	//Adds the student in the arraylist
    	this.slots--;	//Reduce slots number
    	successPrompt(student);	//Prompts success student
    	return true;	//Returns true
    }
    
    
    private void successPrompt(Student student) {
    	System.out.println(Server.GREEN + "Enlistment Successful "+student.getStudentName()+"\n"+ Server.RESET);

    }
    private void courseFull(Student student) {
    	System.out.println(Server.RED + student.getStudentName()+ ": Enlistment Failed" + Server.RESET);
        System.out.println(Server.RED+ "Course is full. Cannot enlist more students." + "\n"+Server.RESET);
    }
    
    //viewing of course state
    public void viewState() {
        System.out.println("==========	   Final Roster     ===========");
        System.out.println("Course: " + courseName);
        System.out.println("Course No.: " + courseNumber);
        System.out.println("==========	 List of Students   ===========");

        for (Student student : enlistedStudents) {
            System.out.printf("%s || %s || %s %n",
                    student.getStudentNumber(),
            		student.getStanding(),
                    student.getStudentName());
        }
        System.out.println("==========	 Nothing follows    ===========");
    }


}

