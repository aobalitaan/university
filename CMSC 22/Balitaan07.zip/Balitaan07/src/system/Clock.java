// A sample runnable for timer
// run the Timer java file
package system;
public class Clock implements Runnable {
	@Override
    public void run() {
        long startTime = System.currentTimeMillis();
        long endTime;
        long elapsedMilliseconds;

        while (true) {
            endTime = System.currentTimeMillis();
            elapsedMilliseconds = endTime - startTime;
            double elapsedSeconds = (double) elapsedMilliseconds / 1000;

            System.out.println("Elapsed time in seconds: " + elapsedSeconds);

            // Check if the thread should run for 10 seconds (10,000 milliseconds)
            if (elapsedMilliseconds >= 10000) {
                break; // Exit the loop after 10 seconds
            }

            try {
                Thread.sleep(1000); // Sleep for 1 second before printing again
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
