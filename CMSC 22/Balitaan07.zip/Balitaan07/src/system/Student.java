package system;

import java.util.ArrayList;
import java.util.List;

public class Student extends Thread{
    private String name;
    private String standing;
    private String studentNumber;
    private int restTime; // Rest time in milliseconds
    
    private boolean isEnlisted;
    private Thread eymis;
    private Server server;
    private Course course;
    
    public static List<Student> students = new ArrayList<>();
    
    public static String FRESHMAN = "Freshman ";
    public static String SOPHOMORE = "Sophomore";
    public static String JUNIOR = "Junior   ";
    public static String SENIOR = "Senior   ";
   

    public Student(String name, String standing, String studentNumber, int restTime) {
    /*
     * Student constructor
     * provide the proper constructor
     */
    	
    	//Constructor initialization for a student
    	this.name = name;
    	this.standing = standing;
    	this.studentNumber = studentNumber;
    	this.restTime = restTime;
    	
    	//Initially, sets the student as not enlisted
        this.isEnlisted = false;
    }

    public String getStudentName() {
        return name;
    }

    public String getStanding() {
        return standing;
    }

    public String getStudentNumber() {
        return studentNumber;
    }

    public int getRestTime() {
        return restTime;
    }

    
    public void viewState() {
        System.out.println("Student Number: " + this.getStudentNumber());
        System.out.println("Name: " + this.getStudentName());
        System.out.println("Standing: " + this.getStanding());
    }
    

    
    public void run() {
    	/*
	    * Student.run()
	    * the Student thread will run until the student is enlisted
	    * this thread will occasionally sleep in intervals of the students restTime
	    * 
	    * check if the server is open (isAlive)
	    * -> call the enlist method of server
	    * else check if terminated
	    */		
    	
    	//Loops while the student is not enlisted
    	while (!this.isEnlisted)
    	{
    		//Applies the rest time
    		try 
    		{
				sleep(this.restTime);
			} 
    		catch (InterruptedException e) {
				e.printStackTrace();
			}
    		
    		//If eymis is already terminated, doesn't try to enlist anymore (ends loop)
    		if (!this.eymis.isAlive())
    		{
    			break;
    		}
    		
    		//Tries to enlist the student and return an indicator to the student's isEnlisted attribute
			this.isEnlisted = this.server.enlist(this.eymis, this, this.course);
    	}
    }
    
  
    public void clickEnlist(Thread eymis, Server server, Course course) {
    	 /*
         * clickEnlist 
         * accepts thread, server and course as parameter
         * the thread, server and course will be assigned to this student
         * this method will start the student thread
         */	
    	
    	//Sets student attributes
    	this.eymis = eymis;
    	this.server = server;
    	this.course = course;
    	
    	//Starts this student's thread
    	this.start();
    }
    


 
}
