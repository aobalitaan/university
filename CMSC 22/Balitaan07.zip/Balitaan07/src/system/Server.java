package system;

public class Server implements Runnable {
	private String name;
	
	public static String RESET = "\u001B[0m";
	public static String GREEN = "\u001B[32m";
	public static String RED = "\u001B[31m";
	public static int OPENING_SECS = 15000;
	
	public Server(String name) {
		this.name = name;
	}
	

    @Override
    public void run() {
    	
	/*
	 * Server.run()
	 * when called, print in terminal that the server is open
	 * "Ey-mis server is now open!"
	 * 
	 * this runnable thread will run for 15 seconds
	 * for reference how timer works for thread, visit the run method of Timer class
	 * 
	 * create a cycle:
	 * 2 secs.  running -> 2 secs. sleeping ->  2secs. running -> 2 secs. sleeping
	 * this cycle continues for 15 seconds
	 * refer to the diagram in the exercise
	 * after 15 seconds, the server will be terminated
	 */
    	//Prompts that server is open
    	System.out.println("Ey-mis server is now open!\n");
    	
    	//Gets the time when the server started
    	long startTime = System.currentTimeMillis();
        long currTime;
        
        long elapsedMilliseconds;
        long remainingTime;

        while (true) {
        	currTime = System.currentTimeMillis();	//Gets current time
        	elapsedMilliseconds = (long) currTime - startTime;	//Subtracts current time and start time to get elapsed time
        	
        	//If elapsed time exceeded the time alotted for server, ends the loop/thread
        	if (elapsedMilliseconds >= OPENING_SECS)
        	{
        		break;
        	}
        	
        	//Implements the 2 second cycle
        	if (elapsedMilliseconds % 4000 >= 2000)
        	{
        		remainingTime = OPENING_SECS - elapsedMilliseconds;	//Calculates how much time is left
        		try
        		{
        			//By default applies 2 second sleep, however, if only 1 second is left sleeps for 1 second (remaining time)
        			Thread.sleep(remainingTime < 2000 ? remainingTime : 2000);
        		} 
        		catch (InterruptedException e) {};
        	}
        }
    }
   
 
    /*
     * enlist (a critical section)
     * accepts thread, student and course object
     * first, check if this server is running (use getState)
     * -> will call the enlistStudent method of Course class
     * -> returns true upon successful enlistment
     * 
     * else
     * -> prompt the user that the enlistment is unsuccessful
     * -> returns false
     * 
     * NOTE: call the enlistmentFailed method for error printing
     */
    
    //Enlist sync function set to default
    synchronized boolean enlist(Thread eymis, Student student, Course course)
    {
    	//If eymis server is turned off/sleeping (not running)
    	if (eymis.getState() != Thread.State.RUNNABLE)
    	{
    		//Prompts user and returns false
    		enlistmentFailed(student);
    		return false;
    	}
    	
    	//If eymis server is runnable, tries to enlist the student
    	return (course.enlistStudent(student));
    	
    }
    
    private void enlistmentFailed(Student student) {
    	System.out.println(Server.RED + student.getStudentName()+ ": Enlistment Failed" + Server.RESET);
		System.out.println(Server.RED +"Server closed or not working\n" + Server.RESET);
    }
    public String getName() {
    	return this.name;
    }
    

}
