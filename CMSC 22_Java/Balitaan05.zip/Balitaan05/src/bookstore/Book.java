package bookstore;

//BOOK CLASS

public class Book {
	
	
	//Book's basic information (super attributes)
	protected String bookTitle;
	protected String bookAuthor;
	protected int bookId;
	
	
	//Constructor call for super attributes of books (ebook and hardcopy)
	public Book(String bookTitle, String bookAuthor, int book_count)
	{
		//Initializes book information
		this.bookTitle = bookTitle;
		this.bookAuthor = bookAuthor;
		this.bookId = book_count + 1;
	}
	
	//Method for viewstate
	public void viewState()
	{
		//Prints book information
		System.out.println("Book Title: " + this.bookTitle);
		System.out.println("Book Author: " + this.bookAuthor);
		
		System.out.println("Book ID: " + this.bookId);
	}
}
