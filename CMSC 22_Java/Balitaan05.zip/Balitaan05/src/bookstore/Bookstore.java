package bookstore;

//Import for Scanner
import java.util.Scanner;

//BOOKSTORE CLASS

public class Bookstore {
	
	
	private String bookstoreName; //Attribute for bookstore name
	
	//Book[] book_list; 	//Bookstore's booklist and bookcount
	private Ebook[] ebookList;
	private HardCopy[] hcopyList;
	private int ebCount;
	private int hcCount;
	private int totalCount;
	
	private Author[] authorList;	//Bookstore's authorlist and authorcount
	private int authCount;
	
	private Scanner input;
	
	//Constants for max book and author counts the bookstore could hold
	private final static int MAX_totalCount = 50;
	private final static int MAX_authCount = 50;
	
	
	public Bookstore(String bookstoreName) //Constructor call for the bookstore
	{
	
		this.bookstoreName = bookstoreName; //Initializes bookstore name
		
		//this.book_list = new Book[MAX_totalCount];	//Initializes bookstore's list of books
		this.ebookList = new Ebook[MAX_totalCount];
		this.hcopyList = new HardCopy[MAX_totalCount];
		
		this.ebCount = 0;
		this.hcCount = 0;
		this.totalCount = 0;
		
		//Initializes bookstore's list of authors
		this.authorList = new Author[MAX_authCount];
		this.authCount = 0;
		
		this.input = new Scanner(System.in);
	}

	
	
	
	//Method for Main Menu
	public void showMainMenu()
	{	
		//Initial greetings
		System.out.println("------------------------");
		System.out.println("Welcome to " + this.bookstoreName + "!");
		System.out.println("\nWhat would you like to do today?");
		
		int choice;
		
		//Main Menu loops unless exited
		while (true)
		{
			System.out.println("[1] Add new records");
			System.out.println("[2] View records");
			System.out.println("[3] Search");
			System.out.println("[0] Exit");
			
			//Gets user choice, returns -1 if the input was string
			choice = enterChoice(input);
			
			//If user chose to exit
			if (choice == 0)
			{
				//Ends the loop
				break;
			}
			
			//If user chose to add new records
			if (choice == 1)
			{
				addRecord(input);
			}
			//If user chose to view records
			else if (choice == 2)
			{
				//views records, passes the bookstore's booklist
				viewRecord(this.ebookList, this.hcopyList);
			}
			//If user chose search function
			else if (choice == 3)
			{
				search(input);
			}
			//If user choice is an invalid one (a string)
			else if (choice == -1)
			{
				continue;
			}
			//Hidden option for View State
			else if (choice == 99)
			{
				viewState();
			}
			//If user choice is an integer but not in choices
			else
			{
				System.out.println("Invalid input!\n");
			}
			System.out.println("\nWhat would you like to do next?");
			
		}
		
		//Closes scanner and exits program
		input.close();
		System.out.println("\nThank you for using " + this.bookstoreName + " app");
		System.out.println("------------------------");
	}
	
	//Method for getting user choice in main menu
	private int enterChoice(Scanner input)
	{
		int choice;
		
		try
		{
			//Gets user input
			choice = input.nextInt();
			//Returns if no anomalies
			return choice;
		}
		catch (Exception e)
		{
			//Tells user if they inputed a string instead of int
			System.out.println("------------------------");
			System.out.println("     Type Mismatch!     ");
			System.out.println("------------------------");
			
			//And returns an indicator/flag
			input.nextLine();
			return (-1);
		}
	}
	
	
	
	
	
	private void addRecord(Scanner input)
	{
		//If already reached maximum book count, tells user and doesn't proceed
		if (this.totalCount >= MAX_totalCount)
		{
			System.out.println("------------------------");
			System.out.println("Booklist is full!");
			System.out.println("------------------------");
			return;
		}
		
		//Gets Book Details from the user, [0] = title, [1] = author name
		String[] newBookDetails = getRecord(input);
		
		//Looks for the author in database, 
		//if existing returns index 
		//if not existing returns a flag
		int authorIndex = authorSearch(newBookDetails[1]);
		
		//If the author is not in system and author list is full doesn't proceed with adding book and author
		if ((this.authCount >= MAX_authCount) &&
			(authorIndex == -1))
		{
			System.out.println("------------------------");
			System.out.println("Authorlist is full!");
			System.out.println("------------------------");
			return;
		}
		
		//If the author is a new one (indicated by a flag)
		if (authorIndex == -1)
		{
			//Instantiate a new author object
			Author newAuthor = new Author(newBookDetails[1], this.authCount);
			
			//Adds the instantiated author to the author list, gives the index of it, iterates author count
			this.authorList[this.authCount] = newAuthor;
			authorIndex = this.authCount;
			this.authCount++;
		}
		
		//Gets Book main type from user (Ebook or HardCopy)
		int type = getBookType(input);
		int subtype;
		
		if (type == 1) //If type is Ebook
		{
			String filename = getFileName(input);	//Gets file name
			subtype = getBookSubType(input, type);	//Gets subtype/format
			Ebook newBook = new Ebook(newBookDetails[0], newBookDetails[1], this.ebCount, subtype, filename); //Instantiate ebook
			
			if (authorList[authorIndex].addBook(newBook) == true)	//Adds it to author's list of ebooks
			{
				this.ebookList[this.ebCount] = newBook;	//Adds the book to the bookstore's database
				this.ebCount++;	//Iterates ebook list count
				this.totalCount++;	//And total number of books
			}
		}
		else if (type == 2)	//If type is HardCopy
		{
			subtype = getBookSubType(input, type);	//Gets subtype from user
			HardCopy newBook = new HardCopy(newBookDetails[0], newBookDetails[1], this.hcCount, subtype);	//Instantiates hard copy object
			
			if (authorList[authorIndex].addBook(newBook) == true)	//Adds the book to author's list of Hard copy
			{
				this.hcopyList[this.hcCount] = newBook;	//Adds the book to the bookstore's datanase
				this.hcCount++;	//Iterates hardcopy list count
				this.totalCount++;	//Iterates total book count
			}
		}
		
	}
	
	private String[] getRecord(Scanner input)
		{
			//Refresh input buffer
			input.nextLine();
			
			
			//Continuously gets book title unless valid (non-empty)
			String book_title;
			while (true)
			{
				System.out.println("------------------------");
				System.out.print("Title: ");
				book_title = input.nextLine();
				
				//If title is non-empty, ends the loop
				if (!(book_title.trim().equals("")))
				{
					break;
				}
				
				System.out.println("------------------------");
				System.out.println("Book Title can't be empty!");
			}
			
			//Continuously gets book author unless valid (non-empty)
			String book_author;
			while (true)
			{
				System.out.println("------------------------");
				System.out.print("Author: ");
				book_author = input.nextLine();
				
				//If author is non-empty, ends the loop
				if (!(book_author.trim().equals("")))
				{
					break;
				}
				
				System.out.println("------------------------");
				System.out.println("Book Author can't be empty!");
			}
			
			System.out.println("------------------------");
			
			//Returns the book details in an array
			String[] newBookDetails = new String[2];
			newBookDetails[0] = book_title;
			newBookDetails[1] = book_author;
			return newBookDetails;
		}
	
	private int getBookType(Scanner input)
	{
		int book_type;	//Initializtaion
		
		while (true)	//Gets book type until valid
		{
			System.out.print("Type of book: Type [1] for electronic; [2] for hard copy - ");
			
			book_type = enterChoice(input);
			
			if (book_type == -1)	//If book type not a number, tries again
			{
				continue;
			}
			if ((book_type != 1) && (book_type != 2))	//If book type not 1 nor 2, tries again
			{
				System.out.println("Invalid Book Type!");
				continue;
			}
			return book_type;	//If everything valid, returns the book type int
		}
	}
	
	private int getBookSubType(Scanner input, int type)
	{
		//For printing
		String message[] = {"Format" , "Type of book",};
		String type1[] = {"Pdf", "hard bound"};
		String type2[] = {"Epub", "soft bound"};
		
		int book_subtype;	//Initialization
		
		while (true)	//Gets book type until valid
		{
			System.out.print(message[type-1] + ": Type [1] for "+ type1[type-1] + "; [2] for " + type2[type-1] + " - ");
			
			book_subtype = enterChoice(input);
			
			if (book_subtype == -1)	//If book subtype not a number, tries again
			{
				continue;
			}
			if ((book_subtype != 1) && (book_subtype != 2))	//If book type not 1 nor 2, tries again
			{
				System.out.println("Invalid Book Subtype!");
				continue;
			}
			return book_subtype;	//If everything valid, returns the book type int
		}
	}
	
	private String getFileName(Scanner input)
	{
		//Refresh input buffer
		input.nextLine();
				
		//Continuously gets book title unless valid (non-empty)
		String filename;
		while (true)
		{
			System.out.println("------------------------");
			System.out.print("Filename: ");
			filename = input.nextLine();
				
			//If filename is non-empty, ends the loop
			if (!(filename.trim().equals("")))
			{
				break;
			}
				
			System.out.println("------------------------");
			System.out.println("File name can't be empty!");
		}
		System.out.println("------------------------");
		return filename;	//return file name
	}
	
	
	
	

	private void viewRecord(Ebook[] ebookList, HardCopy[] hcopyList)
	{
		//If the booklist is empty, doesn't proceed
		if (this.totalCount == 0)
		{
			System.out.println("\n------------------------");
			System.out.println("The list is empty!");
			System.out.println("------------------------");
			return;
		}
		
		
		//Prints the books in the booklist
		System.out.println("\n-----LIST OF ELECTRONIC BOOKS------");
		
		if (ebookList[0] == null)
		{
			System.out.println("No entry.");
		}
		
		for (Ebook ebook : ebookList)
		{
			//Ends if already in the end of the booklist
			if (ebook == null)
			{
				break;
			}
			ebook.ebookDetail();
		}
		
		//Prints the books in the booklist
		System.out.println("\n--------LIST OF HARDCOPIES---------");
		
		if (hcopyList[0] == null)
		{
			System.out.println("No entry.");
		}
		
		for (HardCopy hardcopy : hcopyList)
		{
			//Ends if already in the end of the booklist
			if (hardcopy == null)
			{
				break;
			}
			hardcopy.hardCopyDetail();
		}
	}

	
	
	
	//Method for search choice
	private void search(Scanner input)
	{
		//Refresh input buffer
		input.nextLine();
		
		//Continuously gets author name unless valid (non-empty)
		String author_name;
		while (true)
		{
			System.out.println("------------------------");
			System.out.print("Enter search key (author): ");
			author_name = input.nextLine();
			
			//If author is non-empty, ends the loop
			if (!(author_name.trim().equals("")))
			{
				break;
			}
			
			System.out.println("------------------------");
			System.out.println("Author name can't be empty!");
		}
		System.out.println("------------------------");
		
		//Finds the author in the authorlist, returns index if found, returns -1 if not
		int authorIndex = authorSearch(author_name);
		
		//If author not found, doesn't proceed
		if (authorIndex == -1)
		{
			System.out.println("Author name does not exist.");
			System.out.println("------------------------");
			return;
		}
		
		

		//Indicates that the author was found, and prints their books
		System.out.println("[" + this.authorList[authorIndex].getAuthorId() + "] " + this.authorList[authorIndex].getAuthor());
		viewRecord(this.authorList[authorIndex].getAuthorEbooks(), this.authorList[authorIndex].getAuthorHcopy());
	}

	//Method for finding the author in the authorlist, accepts the name of the author
	private int authorSearch(String author_name)
	{
		
		//Counter variable index
		int authorIndex = 0;
		
		//Looks for the index of the author
		for (Author author : this.authorList)
		{
			//If already in the last item of the list, ends the loop
			if (author == null)
			{
				break;
			}
			//If the author is found
			if (author.getAuthor().toLowerCase().equals(author_name.toLowerCase()))
			{
				//Returns the index
				return authorIndex;
			}
			//Iterates index
			authorIndex++;
		}
			//Returns a flag that author is not yet in the database
		return (-1);
	}	

	
	
	
	//Method for viewState
	public void viewState()
	{
		//Prints bookstore details
		System.out.println("=========================");
		System.out.println("BOOKSLAY APP");
		System.out.println("Bookstore Name: " + this.bookstoreName);
		
		//Prints ebooks in the booklist
		System.out.println("-------------------------");
		System.out.println("Ebooks:");
		System.out.println("-------------------------");
		for (Ebook eb : ebookList)
		{
			if (eb == null)
			{
				break;
			}
			eb.viewState();
			System.out.println("-------------------------");
		}
		
		//Prints ebooks in the booklist
		System.out.println("-------------------------");
		System.out.println("Hardcopy:");
		System.out.println("-------------------------");
		for (HardCopy hc : hcopyList)
		{
			if (hc == null)
			{
			break;
			}
			hc.viewState();
			System.out.println("-------------------------");
		}
		
		//Prints authors in the authorlist
		System.out.println("-------------------------");
		System.out.println("Authors:");
		System.out.println("-------------------------");
		for (Author author : authorList)
		{
			if (author == null)
			{
				break;
			}
			author.viewState();
			System.out.println("-------------------------");
		}
		System.out.println("=========================");
	}
	
	
}
