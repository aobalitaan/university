package bookstore;

public class Ebook extends Book {
	
	private String format;	//Attribute for Ebook format
	private String filename;
	
	private final static String PDF = "Pdf";	//Constants for ebook format
	private final static String EPUB = "Epub";
	
	public Ebook(String bookTitle, String bookAuthor, int book_count, int format, String filename)
	{
		super(bookTitle, bookAuthor, book_count);	//Sets super attributes
		this.format = getformat(format);	//Sets current ebooks format
		this.filename = filename;	//Sets current ebooks filename
	}
	
	private String getformat(int format)
	{
		if (format == 1)
		{
			return(PDF);
		}
		return(EPUB);
	}
	
	public void ebookDetail()
	{
		System.out.println("[" + this.bookId + "] " + this.bookTitle);
		System.out.println("    Author: " + this.bookAuthor);
		System.out.println("    Filename: " + this.filename);
		System.out.println("    Format: " + this.format);
	}
	
	public void viewState()
	{
		super.viewState();
		System.out.println("Format: " + this.format);
		System.out.println("FileName: " + this.filename);
	}
}
