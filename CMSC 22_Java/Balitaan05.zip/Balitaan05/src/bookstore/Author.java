package bookstore;

//AUTHOR CLASS

public class Author {
	//Author basic information
	private int authId;
	private String authName;
	
	//Author's books information
	private Ebook[] authEbList;
	private HardCopy[] authHcList;
	
	private int authEbCount;
	private int authHcCount;
	private int authBookCount;
	
	//Constant for max books an author could hold
	final static int AUTHOR_MAXBOOKCOUNT = 20;
	
	//Constructor call for author
	public Author(String authName, int author_count)
	{
		//Initializes a new author's attributes
		this.authName = authName;
		this.authId = author_count + 1;
		
		//Initializes author's booklist
		this.authEbList = new Ebook[AUTHOR_MAXBOOKCOUNT];
		this.authHcList = new HardCopy[AUTHOR_MAXBOOKCOUNT];
		
		this.authBookCount = 0;
		this.authEbCount = 0;
		this.authHcCount = 0;
	}
	
	int getAuthorId()
	{
		return(this.authId);
	}
	
	String getAuthor()
	{
		return (this.authName);
	}
	
	Ebook[] getAuthorEbooks()
	{
		return (this.authEbList);
	}
	
	HardCopy[] getAuthorHcopy()
	{
		return (this.authHcList);
	}
	
	//Method for adding a book in author's catalog
	boolean addBook(Ebook newBook)
	{
		//If the author already reached max number of books, doesn't add it
		if (this.authBookCount >= AUTHOR_MAXBOOKCOUNT)
		{
			System.out.println("Author booklist is full!");
			//returns an indicator that it wasn't added
			return false;
		}
		
		//If okay, adds the book and iterates bookcount
		this.authEbList[this.authEbCount] = newBook;
		this.authEbCount++;
		this.authBookCount++;
		
		//Returns and indicator that it was added
		return true;
	}
	
	boolean addBook(HardCopy newBook)
	{
		//If the author already reached max number of books, doesn't add it
		if (this.authBookCount >= AUTHOR_MAXBOOKCOUNT)
		{
			System.out.println("Author booklist is full!");
			//returns an indicator that it wasn't added
			return false;
		}
		
		//If okay, adds the book and iterates bookcount
		this.authHcList[this.authHcCount] = newBook;
		this.authHcCount++;
		this.authBookCount++;
		
		//Returns and indicator that it was added
		return true;
	}
	
	
	//Method for viewstate
	public void viewState()
	{
		//Prints author info
		System.out.println("Author ID: " + authId);
		System.out.println("Author Name: " + authName);
		System.out.println("Author BookCount: " + authBookCount);
		
		//Prints author's books
		System.out.println("Books:");
		for (Ebook book : authEbList)
		{
			if (book == null)
			{
				break;
			}
			System.out.println(book.bookTitle);
		}
		for (HardCopy book : authHcList)
		{
			if (book == null)
			{
				break;
			}
			System.out.println(book.bookTitle);
		}
	}
	
}
