package bookstore;

public class HardCopy extends Book {
	
	private String type;	//Type of HardCopy attribute
	
	private final static String HARDBOUND = "Hard Bound";	//Constants for type
	private final static String SOFTBOUND = "Soft Bound";
	
	
	public HardCopy (String bookTitle, String bookAuthor, int book_count, int type)	//Constructor of a HardCpy
	{
		super(bookTitle, bookAuthor, book_count);	//Instantiate super attributes
		this.type = getType(type);	//Sets the current type based on user input
	}
	
	private String getType(int type)
	{
		if (type == 1)
		{
			return(HARDBOUND);
		}
		return(SOFTBOUND);
	}
	
	public void hardCopyDetail()
	{
		System.out.println("[" + this.bookId + "] " + this.bookTitle);
		System.out.println("    Author: " + this.bookAuthor);
		System.out.println("    Type: " + this.type);
	}
	
	public void viewState()
	{
		super.viewState();
		System.out.println("Type: " + this.type);
	}
}
