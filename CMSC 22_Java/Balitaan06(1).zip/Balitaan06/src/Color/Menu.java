package Color;
import java.util.Scanner;

public class Menu {
	
	private Scanner sc;	//Scanner attribute of Menu
	
	
	public Menu()
	{
		this.sc = new Scanner(System.in);	//Initializes scanner
	}
	
	
	//Show Main Menu Method
	public void showMainMenu()
	{
		System.out.println("What color scheme would you like to choose?");
		
		//Main menu loops unless exited
		while (true)
		{	
			//Prints main menu choices
			for (int i = 0; i < colorScheme.SCHEMELIST.size(); i++)
			{
				System.out.println("[" + (i+1) + "] " + colorScheme.SCHEMELIST.get(i));
			}
			System.out.println("[0] Exit");
			
			int schemeIndex = enterChoice(0, colorScheme.SCHEMELIST.size());	//Gets scheme choice (from 0 to 5)
			
			//If scheme choice is 0, exits the program
			if (schemeIndex == 0)
			{
				System.out.println("Goodbye!");
				break;
			}
			
			int colIndex = chooseColor();	//Gets color choice
			
			//If color choice is 12, loops back to the main menu and doesn't proceed to printing
			if (colIndex == 12)
			{
				continue;
			}
			
			//Final printing of scheme and asssociated colors
			colPrinting(schemeIndex, colIndex);
			System.out.println();
			
			System.out.println("What would you like to do next?");
		}
		
		sc.close(); //Closes scanner
	}
	
	
	//Shows Color Picker Method
	private int chooseColor()
	{
		
		//Color Picker Printing
		System.out.println("What color would you like to choose?");
		for (int i = 0; i < colorScheme.COLORLIST.size(); i++)
		{
			System.out.println("[" + i + "] " + colorScheme.COLORLIST.get(i));
		}
		System.out.println("[" + colorScheme.COLORLIST.size() + "] Go Back");
		
		
		return (enterChoice(0, colorScheme.COLORLIST.size())); //Gets color choice (from 0 to 12)
	}
	
	
	//Method for final printing of scheme and associated colors
	private void colPrinting(int schemeIndex, int colIndex)
	{
		colorScheme answer = new colorScheme();	//Initializes a colorScheme object
		
		String colScheme = colorScheme.SCHEMELIST.get(schemeIndex - 1);	//Gets the string equivalent of scheme index
		
		//Does the parametric polymorphism passings
		//Adds corresponding indexes of associated colors
		// % (modulo) 12 was employed for the circular array approach
		switch (colScheme)
		{
			case "Monologous":
				answer.showColors(colScheme, colIndex);
				break;
				
			case "Complementary":
				answer.showColors(colScheme, colIndex, ((colIndex + 6) % 12));
				break;
			
			case "Analogous":	//Analogous adds 11 instead of (-1) to prevent negative index
				answer.showColors(colScheme, colIndex, ((colIndex + 11) % 12), ((colIndex + 1) % 12));
				break;
				
			case "Triadic":
				answer.showColors(colScheme, colIndex, ((colIndex + 4) % 12), ((colIndex + 8) % 12));
				break;
				
			case "Tetradic":
				answer.showColors(colScheme, colIndex, ((colIndex + 2) % 12), ((colIndex + 6) % 12), ((colIndex + 8) % 12));
				break;
		}
		
	}
	
	
	//Additional method for checking valid input
	private int enterChoice(int min, int max)
	{
		String choice;	//Initially set as string input
		int userChoice;	//Converts it to integer
		
		while (true)
		{
			try
			{
				System.out.print("Select an option [" + min + "-" + max + "]>>");
				
				choice = sc.nextLine();
				
				if (choice.trim().equals(""))	//If input is blank or spaces, doesn't accept it
				{
					System.out.println("Empty input!");
					continue;
				}
				
				userChoice = Integer.parseInt(choice);	//Tries to parse the input to integer
				
				if ((userChoice > max) || (userChoice < min))	//If user input out of bounds for the choices, doesn't accept it
				{
					System.out.println("Choice out of range!");
					continue;
				}
				
				break;	//Else, breaks the loop
			}
			catch (Exception e)	//If failed to parse to integer
			{
				System.out.println("Invalid Input!");
			}
		}
		
		System.out.println(userChoice);
		return (userChoice);	//Returns the index of the valid choice
	}
}
