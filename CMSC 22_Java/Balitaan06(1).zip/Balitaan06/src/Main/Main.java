/***************************
 * EXERCISE #6
 * 
 * A simple color scheme program that gets
 * corresponding members of color scheme in color
 * wheel of a specific color. It utilizes polymorpism
 * principles and a circular array approach.
 * 
 * --MODIFIED WITH INHERITANCE PRINCIPLE--
 * 
 * Axel O. Balitaan
 * Created: 2023-10-18 10:32
 * Modified : 2023-10-19 00:18
 * 
 ***************************/

package Main;
import Color.*;

public class Main {
	
	public static void main(String[] args)
	{
		//Instantiates a new menu object
		Menu polyColor = new Menu();
		
		//Calls the main menu method of the object
		polyColor.showMainMenu();
	}
}
